
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm, type SubmitHandler } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { LoginSchema, type LoginFormData } from "@/lib/schemas";
import AuthFormWrapper from "@/components/auth/AuthFormWrapper";
import { useAuth } from "@/contexts/AuthContext";
import type { AuthError, User as FirebaseUser } from "firebase/auth";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { signIn } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(LoginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const onSubmit: SubmitHandler<LoginFormData> = async (data) => {
    setIsLoading(true);
    try {
      const result = await signIn(data.email, data.password);
      if (result && 'code' in result) { // AuthError
        const error = result as AuthError;
        let friendlyMessage = `Error al iniciar sesión: ${error.message} (código: ${error.code})`;

        if (error.code === "auth/user-not-found" || error.code === "auth/wrong-password" || error.code === "auth/invalid-credential") {
          friendlyMessage = "Correo electrónico o contraseña incorrectos.";
        } else if (error.code === "auth/invalid-email") {
          friendlyMessage = "El formato del correo electrónico no es válido.";
        } else if (error.code === "auth/user-disabled") {
          friendlyMessage = "Esta cuenta de usuario ha sido deshabilitada.";
        }
        
        toast({
          title: "Error de inicio de sesión",
          description: friendlyMessage,
          variant: "destructive",
        });
      } else { // FirebaseUser
        const user = result as FirebaseUser;
        toast({
          title: "Inicio de sesión exitoso",
          description: "¡Bienvenido de nuevo!",
        });
        if (user.email === "admin@servilocal.com") {
          router.push("/admin");
        } else {
          router.push("/"); 
        }
      }
    } catch (error) {
      console.error("Unexpected error during sign in:", error);
      toast({
        title: "Error Inesperado",
        description: "Ocurrió un error inesperado al iniciar sesión. Por favor, inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthFormWrapper
      title="Iniciar Sesión"
      description="Accede a tu cuenta de ServiLocal."
      footerContent={
        <>
          ¿No tienes una cuenta?{" "}
          <Button variant="link" asChild className="px-0">
            <Link href="/registro">Regístrate aquí</Link>
          </Button>
          <br />
          <Button variant="link" asChild className="px-0">
            <Link href="/restablecer-contrasena">¿Olvidaste tu contraseña?</Link>
          </Button>
        </>
      }
    >
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Correo Electrónico</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="tu@correo.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contraseña</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input 
                      type={showPassword ? "text" : "password"} 
                      placeholder="••••••••" 
                      {...field} 
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword((prev) => !prev)}
                      aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <Eye className="h-4 w-4" aria-hidden="true" />
                      )}
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Iniciando sesión..." : "Iniciar Sesión"}
          </Button>
        </form>
      </Form>
    </AuthFormWrapper>
  );
}
