
"use client";

import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useEffect, useState } from "react";
import type { User as AppUser } from "@/lib/types"; // Your extended user type
import { getUserProfile } from "@/app/actions"; // Server action
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2 } from "lucide-react"; // Using Loader2 for a spinner

// Placeholder icons if not available in lucide-react directly or to ensure they are defined
const CheckCircleIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.06-1.06l-3.894 3.893-1.48-1.479a.75.75 0 00-1.06 1.061l2.013 2.012a.75.75 0 001.06 0l4.42-4.42z" clipRule="evenodd" />
  </svg>
);

const HeartIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
  </svg>
);


export default function ProfilePage() {
  const { currentUser, loading: authLoading } = useAuth();
  const [userProfile, setUserProfile] = useState<AppUser | null>(null);
  const [internalProfileLoading, setInternalProfileLoading] = useState(true);

  useEffect(() => {
    if (currentUser) {
      setInternalProfileLoading(true); // Indicate profile fetching starts
      getUserProfile(currentUser.uid)
        .then(profile => {
          setUserProfile(profile);
        })
        .catch(error => {
          console.error("Error fetching user profile:", error);
          setUserProfile(null); // Ensure profile is null on error
        })
        .finally(() => {
          setInternalProfileLoading(false); // Profile fetching ends
        });
    } else if (!authLoading) {
      // Auth state resolved, and no user is logged in
      setUserProfile(null);
      setInternalProfileLoading(false);
    }
  }, [currentUser, authLoading]);

  // 1. Auth state is still loading
  if (authLoading) {
    return (
      <div className="container mx-auto px-4 py-8 text-center flex flex-col items-center justify-center min-h-[300px]">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p className="text-lg text-muted-foreground">Cargando autenticación...</p>
      </div>
    );
  }

  // 2. Auth state resolved, but no user is logged in
  if (!currentUser) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <p className="text-xl mb-4">Debes iniciar sesión para ver tu perfil.</p>
        <Button asChild className="mt-2">
          <Link href="/login">Iniciar Sesión</Link>
        </Button>
      </div>
    );
  }

  // 3. User is logged in, but profile data is still fetching
  if (internalProfileLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <Skeleton className="h-8 w-48 mb-2" />
            <Skeleton className="h-4 w-64" />
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="flex flex-col items-center justify-center py-6">
                <Loader2 className="h-8 w-8 animate-spin text-primary mb-3" />
                <p className="text-muted-foreground">Cargando datos del perfil...</p>
            </div>
            <div className="space-y-1">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-6 w-3/4" />
            </div>
            <div className="space-y-1">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-6 w-full" />
            </div>
            <div className="space-y-1">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-6 w-1/2" />
            </div>
            <Skeleton className="h-10 w-36 mt-6" />
          </CardContent>
        </Card>
      </div>
    );
  }

  // 4. User is logged in, profile fetching is done, but profile data couldn't be loaded
  if (!userProfile) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <p className="text-xl text-destructive mb-2">Error al cargar tu perfil.</p>
        <p className="text-muted-foreground mb-4">
          No se pudieron obtener los detalles de tu perfil. Por favor, intenta recargar la página.
        </p>
        <Button onClick={() => window.location.reload()} className="mt-2">
          Recargar Página
        </Button>
      </div>
    );
  }
  
  // 5. User and profile data are loaded successfully
  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="max-w-2xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-headline">Mi Perfil</CardTitle>
          <CardDescription>Gestiona la información de tu cuenta.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">Nombre de Usuario</h3>
            <p className="text-lg">{userProfile.displayName || "No especificado"}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">Correo Electrónico</h3>
            <p className="text-lg">{userProfile.email}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">Rol</h3>
            <p className="text-lg capitalize">{userProfile.role}</p>
          </div>
          
          {userProfile.isVerified && (
            <div className="flex items-center space-x-2 p-3 bg-green-100 dark:bg-green-900 rounded-md">
              <CheckCircleIcon className="h-5 w-5 text-green-600 dark:text-green-400" />
              <p className="text-sm text-green-700 dark:text-green-300">Proveedor Verificado</p>
            </div>
          )}
          {userProfile.isDonor && (
            <div className="flex items-center space-x-2 p-3 bg-blue-100 dark:bg-blue-900 rounded-md">
              <HeartIcon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              <p className="text-sm text-blue-700 dark:text-blue-300">Donador</p>
            </div>
          )}

          {userProfile.role === 'provider' && (
            <Button asChild className="mt-4">
              <Link href="/dashboard/provider/perfil/editar">Editar Perfil de Proveedor</Link>
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

