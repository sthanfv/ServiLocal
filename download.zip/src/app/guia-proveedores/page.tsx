
import { getSiteContent } from "@/app/actions";
import type { SiteContent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, BookOpenText } from "lucide-react";

export const metadata = {
  title: "Guía para Proveedores - ServiLocal",
  description: "Guía completa para proveedores sobre cómo usar y maximizar su presencia en ServiLocal.",
};

const defaultProviderGuideContent = `
  <h2 class="text-xl font-semibold mb-3">1. Crea un Perfil Atractivo</h2>
  <p class="mb-2">Tu perfil es tu carta de presentación. Asegúrate de que tu nombre de negocio, descripción de servicios, categorías y ubicaciones sean claros y precisos. Sube imágenes de buena calidad de tus trabajos anteriores si es aplicable.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">2. Publica Servicios Detallados</h2>
  <p class="mb-2">Cuando publiques un servicio, describe claramente qué incluye, el rango de precios (o si es a convenir) y las áreas que cubres. Utiliza imágenes relevantes y de alta calidad para cada servicio.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">3. Responde Rápidamente a las Consultas</h2>
  <p class="mb-2">Los clientes valoran la prontitud. Intenta responder a los mensajes y solicitudes de cotización lo antes posible. Una buena comunicación es clave para generar confianza.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">4. Fomenta las Calificaciones y Reseñas</h2>
  <p class="mb-2">Después de completar un servicio, anima amablemente a tus clientes a dejar una calificación y reseña en la plataforma. Las buenas reseñas son tu mejor publicidad.</p>

  <h2 class="text-xl font-semibold mb-3 mt-4">5. Mantén tu Información Actualizada</h2>
  <p class="mb-2">Asegúrate de que tu información de contacto, disponibilidad y detalles de servicios estén siempre actualizados para evitar confusiones.</p>
  
  <p class="mt-6 text-sm">Este es un texto de marcador de posición. El contenido real de la Guía para Proveedores se cargará desde el sistema de gestión de contenido.</p>
`;

async function StaticPageContent({ pageId, defaultTitle, icon: IconComponent, defaultContentHtml }: { pageId: string, defaultTitle: string, icon: React.ElementType, defaultContentHtml?: string }) {
  const content: SiteContent | null = await getSiteContent(pageId);
  let displayContent: string;
  let displayTitle: string;
  let lastUpdated: string | null = null;

  if (content) {
    displayTitle = content.title || defaultTitle;
    displayContent = content.content;
    lastUpdated = content.lastUpdatedAt ? new Date(content.lastUpdatedAt as any).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric'}) : 'N/A';
  } else if (defaultContentHtml) {
    displayTitle = defaultTitle;
    displayContent = defaultContentHtml;
  } else {
    return (
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" />
            {defaultTitle}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center text-center py-12">
            <AlertCircle className="h-12 w-12 text-destructive mb-4" />
            <h1 className="text-2xl font-bold mb-2">Contenido no encontrado</h1>
            <p className="text-muted-foreground">
              No pudimos cargar el contenido de esta página. Por favor, inténtalo más tarde.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" /> 
            {displayTitle}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: displayContent }} />
         {lastUpdated && (
         <p className="mt-6 text-sm text-muted-foreground">
          Última actualización: {lastUpdated}
        </p>
        )}
      </CardContent>
    </Card>
  );
}

export default function GuiaProveedoresPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl font-headline text-primary">
          Guía para Proveedores
        </h1>
      </header>
      <StaticPageContent 
        pageId="guia-proveedores" 
        defaultTitle="Guía para Proveedores"
        icon={BookOpenText}
        defaultContentHtml={defaultProviderGuideContent}
      />
    </div>
  );
}

export const revalidate = 86400; // Revalidate static pages daily
