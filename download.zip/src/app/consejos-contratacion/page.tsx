
import { getSiteContent } from "@/app/actions";
import type { SiteContent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Lightbulb } from "lucide-react";

export const metadata = {
  title: "Consejos de Contratación - ServiLocal",
  description: "Sigue nuestros consejos para una experiencia de contratación segura y exitosa en ServiLocal.",
};

const defaultHiringTipsContent = `
  <h2 class="text-xl font-semibold mb-3">1. Define Claramente tus Necesidades</h2>
  <p class="mb-2">Antes de buscar un proveedor, ten claro qué servicio necesitas, el alcance del trabajo y tu presupuesto. Cuanta más información tengas, más fácil será encontrar al profesional adecuado.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">2. Investiga y Compara Proveedores</h2>
  <p class="mb-2">Lee los perfiles de los proveedores, revisa sus calificaciones y reseñas de otros clientes. No dudes en contactar a varios proveedores para solicitar cotizaciones y comparar sus propuestas.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">3. Comunícate de Forma Clara</h2>
  <p class="mb-2">Una vez que elijas un proveedor, asegúrate de comunicar claramente tus expectativas, plazos y cualquier detalle relevante. Mantén una comunicación abierta durante todo el proceso.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">4. Acuerda los Términos por Escrito</h2>
  <p class="mb-2">Es recomendable tener un acuerdo por escrito (incluso un resumen por correo electrónico) que detalle el alcance del servicio, el costo total, las condiciones de pago y los plazos.</p>

  <h2 class="text-xl font-semibold mb-3 mt-4">5. Deja una Reseña Honesta</h2>
  <p class="mb-2">Una vez completado el servicio, comparte tu experiencia dejando una calificación y reseña para el proveedor. Esto ayuda a otros usuarios y a la comunidad de ServiLocal.</p>
  
  <p class="mt-6 text-sm">Este es un texto de marcador de posición. El contenido real de los Consejos de Contratación se cargará desde el sistema de gestión de contenido.</p>
`;

async function StaticPageContent({ pageId, defaultTitle, icon: IconComponent, defaultContentHtml }: { pageId: string, defaultTitle: string, icon: React.ElementType, defaultContentHtml?: string }) {
  const content: SiteContent | null = await getSiteContent(pageId);
  let displayContent: string;
  let displayTitle: string;
  let lastUpdated: string | null = null;

  if (content) {
    displayTitle = content.title || defaultTitle;
    displayContent = content.content;
    lastUpdated = content.lastUpdatedAt ? new Date(content.lastUpdatedAt as any).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric'}) : 'N/A';
  } else if (defaultContentHtml) {
    displayTitle = defaultTitle;
    displayContent = defaultContentHtml;
  } else {
    return (
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" />
            {defaultTitle}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center text-center py-12">
            <AlertCircle className="h-12 w-12 text-destructive mb-4" />
            <h1 className="text-2xl font-bold mb-2">Contenido no encontrado</h1>
            <p className="text-muted-foreground">
              No pudimos cargar el contenido de esta página. Por favor, inténtalo más tarde.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" /> 
            {displayTitle}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: displayContent }} />
         {lastUpdated && (
         <p className="mt-6 text-sm text-muted-foreground">
          Última actualización: {lastUpdated}
        </p>
        )}
      </CardContent>
    </Card>
  );
}

export default function ConsejosContratacionPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl font-headline text-primary">
          Consejos para una Contratación Exitosa
        </h1>
      </header>
      <StaticPageContent 
        pageId="consejos-contratacion" 
        defaultTitle="Consejos de Contratación"
        icon={Lightbulb}
        defaultContentHtml={defaultHiringTipsContent}
      />
    </div>
  );
}

export const revalidate = 86400; // Revalidate static pages daily
