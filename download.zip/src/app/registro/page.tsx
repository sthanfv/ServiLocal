
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm, type SubmitHandler } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { RegisterSchema, type RegisterFormData } from "@/lib/schemas";
import AuthFormWrapper from "@/components/auth/AuthFormWrapper";
import { useAuth } from "@/contexts/AuthContext";
import type { AuthError, User as FirebaseUser } from "firebase/auth";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { createUserDocument } from "@/app/actions"; // Import server action

export default function RegisterPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const { signUp } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const form = useForm<RegisterFormData>({
    resolver: zodResolver(RegisterSchema),
    defaultValues: {
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const onSubmit: SubmitHandler<RegisterFormData> = async (data) => {
    setIsLoading(true);
    try {
      const result = await signUp(data.email, data.password); // From useAuth()

      if (result && 'uid' in result) { // FirebaseUser type guard
        const firebaseUser = result as FirebaseUser;
        
        // Determine role (example: from query param, or a form field if you add one)
        const roleParam = searchParams.get('role');
        const role = roleParam === 'provider' ? 'provider' : 'client';
        
        // Create user document in Firestore
        const createDocResult = await createUserDocument(
          firebaseUser.uid, 
          firebaseUser.email!, // email is guaranteed for email/password users
          firebaseUser.displayName || undefined, // displayName might be null
          role
        );

        if (!createDocResult.success) {
          toast({
            title: "Error de Creación de Perfil",
            description: `Tu cuenta fue creada, pero hubo un problema al guardar tu perfil en la base de datos: ${createDocResult.error}. Por favor, contacta a soporte o intenta registrarte de nuevo más tarde.`,
            variant: "destructive",
            duration: 10000, // Give more time to read this important error
          });
          // Consider if you should sign out the user here or attempt to delete the auth user
          // For now, just prevent further navigation.
          setIsLoading(false);
          return; 
        }
        
        toast({
          title: "Registro Exitoso",
          description: "¡Tu cuenta ha sido creada! Ahora puedes iniciar sesión.",
        });
        router.push("/login");

      } else if (result && 'code' in result) { // AuthError type guard
        const error = result as AuthError;
        let friendlyMessage = `Error al registrar: ${error.message} (código: ${error.code})`;

        if (error.code === "auth/email-already-in-use") {
          friendlyMessage = "Este correo electrónico ya está en uso. Intenta iniciar sesión o usa un correo diferente.";
        } else if (error.code === "auth/weak-password") {
          friendlyMessage = "La contraseña es demasiado débil. Debe tener al menos 6 caracteres.";
        } else if (error.code === "auth/invalid-email") {
          friendlyMessage = "El formato del correo electrónico no es válido.";
        } else if (error.code === "auth/api-key-not-valid") {
          friendlyMessage = "La clave API de Firebase no es válida. Revisa la configuración. (código: auth/api-key-not-valid)";
        }
        
        toast({
          title: "Error de Registro",
          description: friendlyMessage,
          variant: "destructive",
        });
      } else {
        // Should not happen if signUp always returns FirebaseUser or AuthError
        throw new Error("Resultado inesperado del proceso de registro.");
      }
    } catch (error) {
      console.error("Unexpected error during sign up or profile creation:", error);
      toast({
        title: "Error Inesperado",
        description: "Ocurrió un error inesperado durante el registro. Por favor, inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthFormWrapper
      title="Crear una Cuenta"
      description="Únete a ServiLocal para encontrar o proveer servicios."
      footerContent={
        <>
          ¿Ya tienes una cuenta?{" "}
          <Button variant="link" asChild className="px-0">
            <Link href="/login">Inicia sesión aquí</Link>
          </Button>
        </>
      }
    >
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Correo Electrónico</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="tu@correo.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contraseña</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input 
                      type={showPassword ? "text" : "password"} 
                      placeholder="••••••••" 
                      {...field} 
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword((prev) => !prev)}
                      aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <Eye className="h-4 w-4" aria-hidden="true" />
                      )}
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="confirmPassword"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Confirmar Contraseña</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input 
                      type={showConfirmPassword ? "text" : "password"} 
                      placeholder="••••••••" 
                      {...field}
                      className="pr-10"
                    />
                     <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowConfirmPassword((prev) => !prev)}
                      aria-label={showConfirmPassword ? "Ocultar contraseña de confirmación" : "Mostrar contraseña de confirmación"}
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <Eye className="h-4 w-4" aria-hidden="true" />
                      )}
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Creando cuenta..." : "Crear Cuenta"}
          </Button>
        </form>
      </Form>
    </AuthFormWrapper>
  );
}
