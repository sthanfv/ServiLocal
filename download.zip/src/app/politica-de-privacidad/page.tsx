
import { getSiteContent } from "@/app/actions";
import type { SiteContent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, ShieldCheck } from "lucide-react";

export const metadata = {
  title: "Política de Privacidad - ServiLocal",
  description: "Conoce cómo manejamos tu información personal en ServiLocal.",
};

const defaultPrivacyPolicyContent = `
  <h2 class="text-xl font-semibold mb-3">1. Información que Recopilamos</h2>
  <p class="mb-2">Recopilamos información que usted nos proporciona directamente, como cuando crea una cuenta, se comunica con nosotros o utiliza nuestros servicios. Esto puede incluir su nombre, dirección de correo electrónico, número de teléfono y cualquier otra información que elija proporcionar.</p>
  <p class="mb-2">También podemos recopilar información automáticamente cuando utiliza la Plataforma, como su dirección IP, tipo de navegador, páginas visitadas y otra información de uso.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">2. Cómo Utilizamos su Información</h2>
  <p class="mb-2">Utilizamos la información que recopilamos para:</p>
  <ul class="list-disc pl-5 mb-2">
    <li>Proveer, mantener y mejorar nuestros servicios.</li>
    <li>Personalizar su experiencia en la Plataforma.</li>
    <li>Comunicarnos con usted, incluyendo responder a sus comentarios, preguntas y solicitudes.</li>
    <li>Proteger la seguridad e integridad de nuestra Plataforma.</li>
  </ul>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">3. Cómo Compartimos su Información</h2>
  <p class="mb-2">No compartiremos su información personal con terceros, excepto en las siguientes circunstancias:</p>
  <ul class="list-disc pl-5 mb-2">
    <li>Con su consentimiento.</li>
    <li>Con proveedores de servicios que trabajan en nuestro nombre.</li>
    <li>Para cumplir con obligaciones legales.</li>
    <li>Para proteger nuestros derechos y propiedades.</li>
  </ul>
  
  <p class="mt-6 text-sm">Este es un texto de marcador de posición. El contenido real de la Política de Privacidad se cargará desde el sistema de gestión de contenido.</p>
`;

async function StaticPageContent({ pageId, defaultTitle, icon: IconComponent, defaultContentHtml }: { pageId: string, defaultTitle: string, icon: React.ElementType, defaultContentHtml?: string }) {
  const content: SiteContent | null = await getSiteContent(pageId);
  let displayContent: string;
  let displayTitle: string;
  let lastUpdated: string | null = null;

  if (content) {
    displayTitle = content.title || defaultTitle;
    displayContent = content.content;
    lastUpdated = content.lastUpdatedAt ? new Date(content.lastUpdatedAt as any).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric'}) : 'N/A';
  } else if (defaultContentHtml) {
    displayTitle = defaultTitle;
    displayContent = defaultContentHtml;
  } else {
    return (
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" />
            {defaultTitle}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center text-center py-12">
            <AlertCircle className="h-12 w-12 text-destructive mb-4" />
            <h1 className="text-2xl font-bold mb-2">Contenido no encontrado</h1>
            <p className="text-muted-foreground">
              No pudimos cargar el contenido de esta página. Por favor, inténtalo más tarde.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" /> 
            {displayTitle}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: displayContent }} />
        {lastUpdated && (
         <p className="mt-6 text-sm text-muted-foreground">
          Última actualización: {lastUpdated}
        </p>
        )}
      </CardContent>
    </Card>
  );
}

export default function PoliticaPrivacidadPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl font-headline text-primary">
          Política de Privacidad
        </h1>
      </header>
      <StaticPageContent 
        pageId="politica-de-privacidad" 
        defaultTitle="Política de Privacidad"
        icon={ShieldCheck}
        defaultContentHtml={defaultPrivacyPolicyContent}
      />
    </div>
  );
}

export const revalidate = 86400; // Revalidate static pages daily
