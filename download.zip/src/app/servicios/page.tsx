
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, ListFilter, AlertTriangle, Info } from "lucide-react";
import { getActiveServiceCategories, getListedServices } from "@/app/actions";
import type { Service, ServiceCategory } from "@/lib/types";
import ServiceCard from "@/components/services/ServiceCard";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ServiciosPageProps {
  searchParams: {
    categoriaId?: string; // Changed from categoria (name) to categoriaId
    q?: string;
    page?: string;
  };
}

export const metadata = {
  title: "Buscar Servicios - ServiLocal",
  description: "Encuentra servicios locales cualificados en tu área.",
};

export default async function ServiciosPage({ searchParams }: ServiciosPageProps) {
  const { categoriaId, q: searchQuery, page } = searchParams;
  
  const currentPage = parseInt(page || "1", 10);
  // We don't have lastVisibleId for the first page, so we handle filters here.
  // For subsequent pages, lastVisibleId would be passed if we implement pagination.

  const categories: ServiceCategory[] = await getActiveServiceCategories();
  const selectedCategory = categories.find(cat => cat.id === categoriaId);

  const filters = {
    keyword: searchQuery,
    categoryId: categoriaId,
    // locationText: undefined, // Add location filter later
    // minRating: undefined, // Add rating filter later
  };

  // Fetch services. For now, we're not implementing full pagination with cursors in this UI.
  // getListedServices can handle a lastVisibleId if provided.
  const { services, nextPageCursor } = await getListedServices(filters);

  let pageTitle = "Todos los Servicios";
  let pageDescription = "Explora los servicios disponibles en nuestra plataforma o busca algo específico.";
  
  if (selectedCategory) {
    pageTitle = `Servicios de ${selectedCategory.name}`;
    pageDescription = `Encuentra los mejores profesionales de ${selectedCategory.name} en tu área.`;
  } else if (categoriaId && categoriaId !== "all") {
    // Category ID was provided but not found (e.g., invalid ID in URL)
    pageTitle = "Categoría no encontrada";
    pageDescription = "La categoría de servicio que buscas no existe o no está activa.";
  }


  if (searchQuery) {
    pageTitle = `Resultados para "${searchQuery}"`;
    if (selectedCategory) {
      pageTitle += ` en ${selectedCategory.name}`;
    } else if (categoriaId && categoriaId !== "all") {
       pageTitle += ` en categoría desconocida`;
    } else if (categoriaId === "all") {
      pageTitle += ` en todas las categorías`;
    }
    pageDescription = `Mostrando servicios que coinciden con tu búsqueda.`;
  }


  return (
    <div className="space-y-8">
      <header className="mb-10">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl font-headline text-primary">
          {pageTitle}
        </h1>
        <p className="mt-3 text-lg text-foreground/80 max-w-3xl">
          {pageDescription}
        </p>
      </header>

      <Card className="shadow-lg sticky top-16 z-40 bg-background/90 backdrop-blur-sm p-6">
        <form method="GET" action="/servicios" className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
          <div className="md:col-span-6 space-y-1.5">
            <label htmlFor="search-keyword" className="text-xs font-medium text-muted-foreground">Buscar por palabra clave</label>
            <div className="relative">
              <Input
                id="search-keyword"
                name="q"
                type="search"
                placeholder="Ej: plomero, reparación de fugas..."
                className="w-full h-11 pl-10 text-base"
                defaultValue={searchQuery}
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            </div>
          </div>
          <div className="md:col-span-4 space-y-1.5">
            <label htmlFor="search-category" className="text-xs font-medium text-muted-foreground">Categoría</label>
            <Select name="categoriaId" defaultValue={categoriaId || "all"}>
              <SelectTrigger id="search-category" className="w-full h-11 text-base">
                <SelectValue placeholder="Todas las categorías" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las categorías</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button className="w-full md:col-span-2 h-11 bg-accent hover:bg-accent/90 text-accent-foreground text-base" type="submit">
            <Search className="mr-2 h-5 w-5" />
            Buscar
          </Button>
        </form>
        {/* Future advanced filters button
        <div className="mt-4">
           <Button variant="outline" className="w-full md:w-auto h-10 text-sm" disabled>
              <ListFilter className="mr-2 h-4 w-4" />
              Filtros Avanzados (Ubicación, Calificación)
          </Button>
        </div>
        */}
      </Card>

      {categoriaId && categoriaId !== "all" && !selectedCategory && services.length === 0 && (
         <Card className="w-full shadow-md">
          <CardHeader>
              <CardTitle className="text-center text-xl text-destructive">Categoría no Válida</CardTitle>
          </CardHeader>
          <CardContent className="text-center py-12">
              <AlertTriangle className="mx-auto h-16 w-16 text-destructive mb-6" />
              <h3 className="text-2xl font-semibold text-foreground mb-3">
                Categoría No Encontrada
              </h3>
              <p className="text-muted-foreground text-lg">
                La categoría de servicios especificada no existe o ha sido eliminada.
              </p>
              <Button asChild variant="link" className="mt-6 text-lg">
                <a href="/servicios">Ver todas las categorías</a>
              </Button>
          </CardContent>
        </Card>
      )}

      {services.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>
      ) : (
        (!categoriaId || categoriaId === "all" || selectedCategory) && ( // Show "no services" only if category is valid or "all" or no category selected
          <Card className="w-full shadow-md">
            <CardHeader>
                <CardTitle className="text-center text-xl text-primary">No hay servicios disponibles</CardTitle>
            </CardHeader>
            <CardContent className="text-center py-12">
                <Info className="mx-auto h-16 w-16 text-muted-foreground/70 mb-6" />
                <h3 className="text-2xl font-semibold text-foreground mb-3">
                  No se encontraron servicios
                </h3>
                <p className="text-muted-foreground text-lg">
                  Actualmente no hay servicios que coincidan con tu búsqueda
                  {selectedCategory ? ` en la categoría "${selectedCategory.name}"` : (categoriaId === "all" ? " en todas las categorías" : '')}.
                </p>
                <p className="text-muted-foreground mt-4">
                    Intenta con otros filtros o vuelve más tarde. ¡Nuevos servicios se añaden constantemente!
                </p>
                <Button asChild variant="link" className="mt-6 text-lg">
                  <a href="/">Volver a la Página Principal</a>
                </Button>
            </CardContent>
          </Card>
        )
      )}

      {/* Basic Pagination (Placeholder) - Full pagination needs more state management client-side or different server action logic */}
      {/* { (currentPage > 1 || nextPageCursor) && (
        <div className="flex justify-center items-center space-x-4 mt-8">
          {currentPage > 1 && (
            <Button variant="outline" asChild>
              <Link href={`/servicios?q=${searchQuery || ''}&categoriaId=${categoriaId || ''}&page=${currentPage - 1}`}>Anterior</Link>
            </Button>
          )}
          {nextPageCursor && (
             <Button variant="outline" asChild>
              <Link href={`/servicios?q=${searchQuery || ''}&categoriaId=${categoriaId || ''}&page=${currentPage + 1}`}>Siguiente</Link>
            </Button>
          )}
        </div>
      )} */}

    </div>
  );
}
