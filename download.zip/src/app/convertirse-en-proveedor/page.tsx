
import { getSiteContent } from "@/app/actions";
import type { SiteContent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export const metadata = {
  title: "Conviértete en Proveedor - ServiLocal",
  description: "Ofrece tus servicios en ServiLocal y llega a más clientes. Regístrate hoy.",
};

const defaultBecomeProviderContent = `
  <h2 class="text-xl font-semibold mb-3">Únete a Nuestra Comunidad de Profesionales</h2>
  <p class="mb-2">ServiLocal te ofrece una plataforma para conectar con clientes que necesitan tus habilidades. Al registrarte como proveedor, podrás:</p>
  <ul class="list-disc pl-5 mb-2">
    <li>Crear un perfil profesional detallado.</li>
    <li>Publicar tus servicios específicos con descripciones y precios.</li>
    <li>Recibir solicitudes de cotización y mensajes directos de clientes.</li>
    <li>Aumentar tu visibilidad y hacer crecer tu negocio.</li>
  </ul>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">¿Cómo Empezar?</h2>
  <p class="mb-2">Es muy sencillo:</p>
  <ol class="list-decimal pl-5 mb-2">
    <li>Haz clic en el botón "Regístrate como Proveedor Ahora" que encontrarás más abajo.</li>
    <li>Completa el formulario de registro con tu correo electrónico y crea una contraseña.</li>
    <li>Una vez registrado, accede a tu panel de proveedor para completar tu perfil y comenzar a publicar tus servicios.</li>
  </ol>
  
  <p class="mb-2">¡No esperes más para llegar a nuevos clientes y expandir tu alcance!</p>
  <p class="mt-6 text-sm">Este es un texto de marcador de posición. El contenido real de esta sección se cargará desde el sistema de gestión de contenido.</p>
`;

async function StaticPageContent({ pageId, defaultTitle, icon: IconComponent, defaultContentHtml }: { pageId: string, defaultTitle: string, icon: React.ElementType, defaultContentHtml?: string}) {
  const content: SiteContent | null = await getSiteContent(pageId);
  let displayContent: string;
  let displayTitle: string;
  let lastUpdated: string | null = null;

  if (content) {
    displayTitle = content.title || defaultTitle;
    displayContent = content.content;
    lastUpdated = content.lastUpdatedAt ? new Date(content.lastUpdatedAt as any).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric'}) : 'N/A';
  } else if (defaultContentHtml) {
    displayTitle = defaultTitle;
    displayContent = defaultContentHtml;
  } else {
     return (
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" />
            {defaultTitle}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center text-center py-12">
            <AlertCircle className="h-12 w-12 text-destructive mb-4" />
            <h1 className="text-2xl font-bold mb-2">Contenido no encontrado</h1>
            <p className="text-muted-foreground">
              No pudimos cargar el contenido de esta página. Por favor, inténtalo más tarde.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" />
            {displayTitle}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: displayContent }} />
         {lastUpdated && (
         <p className="mt-6 text-sm text-muted-foreground">
          Última actualización: {lastUpdated}
        </p>
        )}
      </CardContent>
    </Card>
  );
}


export default function ConvertirseEnProveedorPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl font-headline text-primary">
          Conviértete en Proveedor en ServiLocal
        </h1>
        <p className="mt-3 text-lg text-foreground/80 max-w-2xl mx-auto">
          Únete a nuestra creciente comunidad de profesionales. Es fácil y rápido empezar a ofrecer tus servicios.
        </p>
      </header>
      <StaticPageContent 
        pageId="convertirse-en-proveedor" 
        defaultTitle="Información para Proveedores"
        icon={Briefcase}
        defaultContentHtml={defaultBecomeProviderContent}
      />
      <div className="mt-12 text-center">
        <Button size="lg" asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
          <Link href="/registro?role=provider">Regístrate como Proveedor Ahora</Link>
        </Button>
      </div>
    </div>
  );
}

export const revalidate = 86400; // Revalidate static pages daily
