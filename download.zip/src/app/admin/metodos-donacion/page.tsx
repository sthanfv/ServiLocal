
"use client";

import { useEffect, useState } from "react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import {
  createDonationMethod,
  deleteDonationMethod,
  getAllDonationMethods,
  updateDonationMethod,
} from "@/app/actions";
import type { DonationMethod } from "@/lib/types";
import { DonationMethodSchema, type DonationMethodFormData } from "@/lib/schemas";
import { Gift, PlusCircle, Edit, Trash2, Loader2, AlertTriangle, Info, Image as ImageIcon } from "lucide-react";
import Image from "next/image";

export default function AdminMetodosDonacionPage() {
  const { toast } = useToast();
  const [methods, setMethods] = useState<DonationMethod[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentMethod, setCurrentMethod] = useState<DonationMethod | null>(null);
  const [errorFetching, setErrorFetching] = useState<string | null>(null);

  const form = useForm<DonationMethodFormData>({
    resolver: zodResolver(DonationMethodSchema),
    defaultValues: {
      name: "",
      instructions: "",
      incentiveMessage: "",
      iconUrl: "",
      isActive: true,
      displayOrder: 0,
    },
  });

  const fetchMethods = async () => {
    setIsLoading(true);
    setErrorFetching(null);
    try {
      const fetchedMethods = await getAllDonationMethods();
      setMethods(fetchedMethods);
    } catch (error) {
      console.error("Error fetching donation methods:", error);
      setErrorFetching("No se pudieron cargar los métodos de donación. Inténtalo de nuevo más tarde.");
      toast({
        title: "Error al cargar métodos",
        description: (error as Error).message || "Ocurrió un error desconocido.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMethods();
  }, []);

  const handleCreateNew = () => {
    setCurrentMethod(null);
    form.reset({
      name: "",
      instructions: "",
      incentiveMessage: "",
      iconUrl: "",
      isActive: true,
      displayOrder: methods.length > 0 ? Math.max(...methods.map(m => m.displayOrder)) + 1 : 0,
    });
    setIsModalOpen(true);
  };

  const handleEdit = (method: DonationMethod) => {
    setCurrentMethod(method);
    form.reset({
      name: method.name,
      instructions: method.instructions,
      incentiveMessage: method.incentiveMessage || "",
      iconUrl: method.iconUrl || "",
      isActive: method.isActive,
      displayOrder: method.displayOrder,
    });
    setIsModalOpen(true);
  };

  const onSubmit: SubmitHandler<DonationMethodFormData> = async (data) => {
    setIsSubmitting(true);
    try {
      let result;
      if (currentMethod) {
        result = await updateDonationMethod(currentMethod.id, data);
        toast({ title: "Método Actualizado", description: "El método de donación ha sido actualizado." });
      } else {
        result = await createDonationMethod(data);
        toast({ title: "Método Creado", description: "El nuevo método de donación ha sido creado." });
      }

      if (result.success) {
        setIsModalOpen(false);
        fetchMethods();
      } else {
        toast({
          title: currentMethod ? "Error al Actualizar" : "Error al Crear",
          description: result.error || "Ocurrió un error desconocido.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error Inesperado",
        description: (error as Error).message || "Ocurrió un error al procesar la solicitud.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (methodId: string) => {
    try {
      const result = await deleteDonationMethod(methodId);
      if (result.success) {
        toast({ title: "Método Eliminado", description: "El método de donación ha sido eliminado." });
        fetchMethods();
      } else {
        toast({
          title: "Error al Eliminar",
          description: result.error || "Ocurrió un error desconocido.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error Inesperado",
        description: (error as Error).message || "Ocurrió un error al procesar la solicitud.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Gift className="h-8 w-8" />
            Gestión de Métodos de Donación
          </h1>
          <p className="text-muted-foreground">
            Administra los diferentes métodos por los cuales los usuarios pueden apoyar el proyecto.
          </p>
        </div>
        <Button onClick={handleCreateNew} className="w-full sm:w-auto">
          <PlusCircle className="mr-2 h-5 w-5" />
          Crear Nuevo Método
        </Button>
      </header>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{currentMethod ? "Editar Método de Donación" : "Crear Nuevo Método de Donación"}</DialogTitle>
            <DialogDescription>
              {currentMethod ? "Modifica los detalles del método." : "Completa el formulario para añadir un nuevo método."}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 p-1">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nombre del Método</FormLabel>
                    <FormControl>
                      <Input placeholder="Ej: Transferencia Bancaria" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="instructions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Instrucciones</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Detalles sobre cómo realizar la donación..." {...field} rows={5} />
                    </FormControl>
                    <FormDescription>
                      Proporciona información clara para el usuario.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="incentiveMessage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mensaje de Incentivo (Opcional)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Ej: ¡Gracias! Tu nombre aparecerá en nuestra web." {...field} rows={2}/>
                    </FormControl>
                     <FormDescription>
                      Pequeño mensaje si hay algún beneficio o agradecimiento especial.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="iconUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL del Ícono (Opcional)</FormLabel>
                    <FormControl>
                      <Input placeholder="https://ejemplo.com/icono.png" {...field} />
                    </FormControl>
                    <FormDescription>
                      URL completa de una imagen para representar el método.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="displayOrder"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Orden de Visualización</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="0" {...field} />
                    </FormControl>
                    <FormDescription>
                      Número menor aparece primero. Usado para ordenar en la página pública.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Activo</FormLabel>
                      <FormDescription>
                        Indica si este método estará visible y usable.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <DialogFooter className="pt-4">
                 <DialogClose asChild>
                    <Button type="button" variant="outline" disabled={isSubmitting}>Cancelar</Button>
                 </DialogClose>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  {currentMethod ? "Guardar Cambios" : "Crear Método"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle>Listado de Métodos de Donación</CardTitle>
          <CardDescription>
            Administra todos los métodos de donación. Actualmente hay {methods.length} método(s).
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="ml-2">Cargando métodos...</p>
            </div>
          ) : errorFetching ? (
             <div className="text-center py-10 text-destructive">
                <AlertTriangle className="mx-auto h-12 w-12 mb-4" />
                <p className="text-xl font-semibold">{errorFetching}</p>
             </div>
          ) : methods.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Info className="mx-auto h-12 w-12 mb-4" />
              <p className="text-xl font-semibold">No hay métodos de donación creados.</p>
              <p>Empieza creando uno para permitir que los usuarios apoyen el proyecto.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px] hidden sm:table-cell">Icono</TableHead>
                  <TableHead>Nombre</TableHead>
                  <TableHead className="hidden md:table-cell text-center">Orden</TableHead>
                  <TableHead className="text-center">Activo</TableHead>
                  <TableHead className="text-right w-[120px]">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {methods.map((method) => (
                  <TableRow key={method.id}>
                    <TableCell className="hidden sm:table-cell">
                       {method.iconUrl && method.iconUrl.trim() !== '' ? (
                        <div className="relative h-10 w-10">
                          <Image 
                              src={method.iconUrl} 
                              alt={method.name} 
                              layout="fill"
                              objectFit="contain"
                              className="rounded-sm"
                              data-ai-hint="donation method icon"
                          />
                        </div>
                      ) : (
                        <ImageIcon className="h-6 w-6 text-muted-foreground" />
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{method.name}</TableCell>
                    <TableCell className="hidden md:table-cell text-center">{method.displayOrder}</TableCell>
                    <TableCell className="text-center">
                      <Switch checked={method.isActive} disabled className="opacity-100 scale-75" />
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="outline" size="icon" onClick={() => handleEdit(method)} title="Editar">
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Editar Método</span>
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="icon" title="Eliminar">
                            <Trash2 className="h-4 w-4" />
                             <span className="sr-only">Eliminar Método</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>¿Estás seguro de eliminar este método de donación?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Esta acción no se puede deshacer. Esto eliminará permanentemente el método:
                              <strong className="block mt-1">"{method.name}"</strong>.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDelete(method.id)}>
                              Sí, eliminar
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
