
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Briefcase } from "lucide-react";

export default function AdminServiciosPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <Briefcase className="h-8 w-8" />
          Moderación de Servicios
        </h1>
        <p className="text-muted-foreground">
          Revisa, aprueba o rechaza los servicios publicados por los proveedores.
        </p>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Listado de Servicios</CardTitle>
          <CardDescription>
            Servicios pendientes de aprobación, activos y rechazados.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">La tabla de servicios, filtros y acciones de moderación se implementarán aquí.</p>
          {/* TODO: Implementar tabla de servicios, filtros, paginación y acciones */}
        </CardContent>
      </Card>
    </div>
  );
}
