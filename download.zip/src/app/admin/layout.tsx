
import AdminRouteGuard from "@/components/auth/AdminRouteGuard";
import AdminSidebar from "@/components/admin/AdminSidebar";
import type { Metadata } from "next";
// Import SidebarTrigger y useSidebar de ui/sidebar, y SidebarProvider
import { SidebarProvider } from "@/components/ui/sidebar";
import MobileAdminSidebarTrigger from "@/components/admin/MobileAdminSidebarTrigger";


export const metadata: Metadata = {
  title: "Panel de Administración - ServiLocal",
  description: "Gestión interna de la plataforma ServiLocal.",
};

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <AdminRouteGuard>
      <SidebarProvider defaultOpen> {/* defaultOpen se aplica al estado del sidebar de escritorio */}
        <MobileAdminSidebarTrigger /> {/* Añadir el disparador móvil aquí */}
        <div className="flex flex-1 flex-col sm:flex-row min-h-0 bg-background">
          <AdminSidebar />
          <main className="flex-1 w-full overflow-y-auto overflow-x-hidden bg-card p-4 md:p-6 lg:p-8 relative z-0">
            {children}
          </main>
        </div>
      </SidebarProvider>
    </AdminRouteGuard>
  );
}

