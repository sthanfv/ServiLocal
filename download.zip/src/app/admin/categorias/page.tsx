
"use client";

import { useEffect, useState } from "react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import {
  createServiceCategory,
  deleteServiceCategory,
  getAllServiceCategories,
  updateServiceCategory,
} from "@/app/actions";
import type { ServiceCategory } from "@/lib/types";
import { ServiceCategorySchema, type ServiceCategoryFormData } from "@/lib/schemas";
import { LayoutList, PlusCircle, Edit, Trash2, Loader2, AlertTriangle, Info } from "lucide-react";

export default function AdminCategoriasPage() {
  const { toast } = useToast();
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState<ServiceCategory | null>(null);
  const [errorFetching, setErrorFetching] = useState<string | null>(null);

  const form = useForm<ServiceCategoryFormData>({
    resolver: zodResolver(ServiceCategorySchema),
    defaultValues: {
      name: "",
      description: "",
      slug: "",
      isActive: true,
      iconUrl: "",
    },
  });

  const fetchCategories = async () => {
    setIsLoading(true);
    setErrorFetching(null);
    try {
      const fetchedCategories = await getAllServiceCategories();
      setCategories(fetchedCategories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      setErrorFetching("No se pudieron cargar las categorías. Inténtalo de nuevo más tarde.");
      toast({
        title: "Error al cargar categorías",
        description: (error as Error).message || "Ocurrió un error desconocido.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleCreateNew = () => {
    setCurrentCategory(null);
    form.reset({
      name: "",
      description: "",
      slug: "",
      isActive: true,
      iconUrl: "",
    });
    setIsModalOpen(true);
  };

  const handleEdit = (category: ServiceCategory) => {
    setCurrentCategory(category);
    form.reset({
      name: category.name,
      description: category.description,
      slug: category.slug,
      isActive: category.isActive,
      iconUrl: category.iconUrl || "",
    });
    setIsModalOpen(true);
  };

  const onSubmit: SubmitHandler<ServiceCategoryFormData> = async (data) => {
    setIsSubmitting(true);
    try {
      let result;
      if (currentCategory) {
        result = await updateServiceCategory(currentCategory.id, data);
        toast({ title: "Categoría Actualizada", description: "La categoría ha sido actualizada exitosamente." });
      } else {
        result = await createServiceCategory(data);
        toast({ title: "Categoría Creada", description: "La nueva categoría ha sido creada exitosamente." });
      }

      if (result.success) {
        setIsModalOpen(false);
        fetchCategories(); // Re-fetch categories
      } else {
        toast({
          title: currentCategory ? "Error al Actualizar" : "Error al Crear",
          description: result.error || "Ocurrió un error desconocido.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error Inesperado",
        description: (error as Error).message || "Ocurrió un error al procesar la solicitud.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (categoryId: string) => {
    try {
      const result = await deleteServiceCategory(categoryId);
      if (result.success) {
        toast({ title: "Categoría Eliminada", description: "La categoría ha sido eliminada exitosamente." });
        fetchCategories(); // Re-fetch categories
      } else {
        toast({
          title: "Error al Eliminar",
          description: result.error || "Ocurrió un error desconocido.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error Inesperado",
        description: (error as Error).message || "Ocurrió un error al procesar la solicitud.",
        variant: "destructive",
      });
    }
  };
  
  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .trim()
      .replace(/\s+/g, '-') 
      .replace(/[^\w-]+/g, '') 
      .replace(/--+/g, '-'); 
  };

  const handleNameChangeForSlug = (event: React.ChangeEvent<HTMLInputElement>) => {
    const nameValue = event.target.value;
    form.setValue("name", nameValue); 
    if (!form.formState.dirtyFields.slug) { 
      form.setValue("slug", generateSlug(nameValue), { shouldValidate: true });
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <LayoutList className="h-8 w-8" />
            Gestión de Categorías de Servicios
          </h1>
          <p className="text-muted-foreground">
            Crea, edita y organiza las categorías de servicios disponibles en la plataforma.
          </p>
        </div>
        <Button onClick={handleCreateNew} className="w-full sm:w-auto">
          <PlusCircle className="mr-2 h-5 w-5" />
          Crear Nueva Categoría
        </Button>
      </header>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{currentCategory ? "Editar Categoría" : "Crear Nueva Categoría"}</DialogTitle>
            <DialogDescription>
              {currentCategory ? "Modifica los detalles de la categoría." : "Completa el formulario para añadir una nueva categoría."}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 p-1">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nombre de la Categoría</FormLabel>
                    <FormControl>
                      <Input placeholder="Ej: Plomería" {...field} onChange={handleNameChangeForSlug} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Slug (URL amigable)</FormLabel>
                    <FormControl>
                      <Input placeholder="Ej: plomeria" {...field} />
                    </FormControl>
                    <FormDescription>
                      Solo letras minúsculas, números y guiones. Se genera automáticamente pero puedes ajustarlo.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descripción</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Una breve descripción de la categoría..." {...field} rows={4} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="iconUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL del Ícono (Opcional)</FormLabel>
                    <FormControl>
                      <Input placeholder="https://ejemplo.com/icono.png" {...field} />
                    </FormControl>
                    <FormDescription>
                      URL completa de una imagen para representar la categoría.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Activa</FormLabel>
                      <FormDescription>
                        Indica si la categoría estará visible para los usuarios.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <DialogFooter className="pt-4">
                 <DialogClose asChild>
                    <Button type="button" variant="outline" disabled={isSubmitting}>Cancelar</Button>
                 </DialogClose>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  {currentCategory ? "Guardar Cambios" : "Crear Categoría"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle>Listado de Categorías</CardTitle>
          <CardDescription>
            Administra todas las categorías de servicios. Actualmente hay {categories.length} categoría(s).
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="ml-2">Cargando categorías...</p>
            </div>
          ) : errorFetching ? (
             <div className="text-center py-10 text-destructive">
                <AlertTriangle className="mx-auto h-12 w-12 mb-4" />
                <p className="text-xl font-semibold">{errorFetching}</p>
             </div>
          ) : categories.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Info className="mx-auto h-12 w-12 mb-4" />
              <p className="text-xl font-semibold">No hay categorías creadas.</p>
              <p>Empieza creando una nueva categoría para organizar los servicios.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px] hidden sm:table-cell">Icono</TableHead>
                  <TableHead>Nombre</TableHead>
                  <TableHead className="hidden md:table-cell">Slug</TableHead>
                  <TableHead className="hidden lg:table-cell max-w-xs truncate">Descripción</TableHead>
                  <TableHead className="text-center">Activa</TableHead>
                  <TableHead className="text-right w-[120px]">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((category) => (
                  <TableRow key={category.id}>
                    <TableCell className="hidden sm:table-cell">
                      {category.iconUrl && category.iconUrl.trim() !== '' ? (
                        <>
                          <img 
                              src={category.iconUrl} 
                              alt={category.name} 
                              className="h-8 w-8 object-contain rounded-sm" 
                              data-ai-hint="category icon"
                              onError={(e) => { 
                                const imgElement = e.target as HTMLImageElement;
                                imgElement.style.display = 'none'; 
                                const nextSibling = imgElement.nextElementSibling;
                                if (nextSibling instanceof HTMLElement) {
                                  nextSibling.style.display = 'block';
                                }
                              }}
                          />
                          <LayoutList className="h-6 w-6 text-muted-foreground" style={{display: 'none'}} />
                        </>
                      ) : (
                        <LayoutList className="h-6 w-6 text-muted-foreground" />
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{category.name}</TableCell>
                    <TableCell className="hidden md:table-cell text-muted-foreground">{category.slug}</TableCell>
                    <TableCell className="hidden lg:table-cell text-sm text-muted-foreground max-w-xs truncate" title={category.description}>
                        {category.description}
                    </TableCell>
                    <TableCell className="text-center">
                      <Switch checked={category.isActive} disabled className="opacity-100 scale-75" />
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="outline" size="icon" onClick={() => handleEdit(category)} title="Editar">
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Editar Categoría</span>
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="icon" title="Eliminar">
                            <Trash2 className="h-4 w-4" />
                             <span className="sr-only">Eliminar Categoría</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>¿Estás seguro de eliminar esta categoría?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Esta acción no se puede deshacer. Esto eliminará permanentemente la categoría
                              <strong className="block mt-1">"{category.name}"</strong>.
                              Los servicios asociados a esta categoría podrían quedar sin categorizar o requerir una reasignación manual.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDelete(category.id)}>
                              Sí, eliminar
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
