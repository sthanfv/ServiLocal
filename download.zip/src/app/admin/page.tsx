
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { BarChart, Users, Briefcase, AlertCircle, MailWarning, CheckCircle, ShieldCheck } from "lucide-react";

// Estas estadísticas son placeholders y se conectarán a datos reales más adelante
const stats = [
  { title: "Total Usuarios", value: "0", icon: Users, color: "text-blue-500", link: "/admin/usuarios" },
  { title: "Total Proveedores", value: "0", icon: Briefcase, color: "text-green-500", link: "/admin/usuarios?role=provider" },
  { title: "Servicios Activos", value: "0", icon: CheckCircle, color: "text-sky-500", link: "/admin/servicios?status=active" },
  { title: "Servicios Pendientes", value: "0", icon: MailWarning, color: "text-yellow-500", link: "/admin/servicios?status=pending_approval" },
  { title: "Solicitudes Pendientes", value: "0", icon: AlertCircle, color: "text-orange-500", link: "/admin/solicitudes-publicas?status=pending_approval" },
  { title: "Reportes Nuevos", value: "0", icon: AlertCircle, color: "text-red-500", link: "/admin/reportes?status=new" },
];


export default function AdminDashboardPage() {
  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <ShieldCheck className="h-8 w-8 text-primary" /> Panel de Administración
        </h1>
        <p className="text-muted-foreground">
          Visión general y acceso rápido a las funciones de gestión de ServiLocal.
        </p>
      </header>
      
      <section>
        <h2 className="text-2xl font-semibold mb-4">Estadísticas Rápidas</h2>
         <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {stats.map((stat) => (
            <Card key={stat.title} className="shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.title}
                </CardTitle>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground pt-1">
                  <a href={stat.link} className="hover:underline">Ver detalles</a>
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart className="h-6 w-6 text-primary" />
              Actividad Reciente
            </CardTitle>
            <CardDescription>
              Próximamente: un resumen de las últimas acciones y eventos importantes en la plataforma.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Esta sección mostrará notificaciones y actividades relevantes para el administrador.
            </p>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
