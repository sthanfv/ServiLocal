
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { MessageSquareWarning } from "lucide-react";

export default function AdminSolicitudesPublicasPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <MessageSquareWarning className="h-8 w-8" />
          Moderación de Solicitudes Públicas
        </h1>
        <p className="text-muted-foreground">
          Revisa y gestiona las solicitudes de servicio publicadas por los clientes.
        </p>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Listado de Solicitudes</CardTitle>
          <CardDescription>
            Solicitudes pendientes de aprobación, activas y rechazadas.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">La tabla de solicitudes públicas y las acciones de moderación se implementarán aquí.</p>
          {/* TODO: Implementar tabla de solicitudes, filtros y acciones */}
        </CardContent>
      </Card>
    </div>
  );
}
