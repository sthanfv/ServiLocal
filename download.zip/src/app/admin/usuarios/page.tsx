
"use client";

import { Card, CardContent, CardDescription as PageCardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription as DialogModalDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription, // Added FormDescription here
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { getAllUsers, updateUserAdminDetails } from "@/app/actions"; // Ensure updateUserAdminDetails is imported
import type { User } from "@/lib/types";
import { Users as UsersIcon, CheckCircle, XCircle, ShieldCheck, ShoppingBag, Edit, Info, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const UserEditSchema = z.object({
  role: z.enum(['client', 'provider', 'admin']),
  isVerified: z.boolean().optional(),
  isDonor: z.boolean(),
});
type UserEditFormData = z.infer<typeof UserEditSchema>;

function RoleBadge({ role }: { role: User['role'] }) {
  let icon = <ShoppingBag className="h-4 w-4 mr-1.5" />;
  let text = "Cliente";
  let colorClasses = "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300";

  if (role === 'provider') {
    icon = <ShieldCheck className="h-4 w-4 mr-1.5" />;
    text = "Proveedor";
    colorClasses = "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300";
  } else if (role === 'admin') {
    icon = <UsersIcon className="h-4 w-4 mr-1.5" />;
    text = "Admin";
    colorClasses = "bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300";
  }

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colorClasses}`}>
      {icon}
      {text}
    </span>
  );
}

const formatDate = (dateString: string | undefined | Date) => {
  if (!dateString) return 'N/A';
  try {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch (error) {
    return 'Fecha inválida';
  }
};

export default function AdminUsuariosPage() {
  const { toast } = useToast();
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentUserToEdit, setCurrentUserToEdit] = useState<User | null>(null);
  const [errorFetching, setErrorFetching] = useState<string | null>(null);

  const form = useForm<UserEditFormData>({
    resolver: zodResolver(UserEditSchema),
  });

  const fetchUsers = async () => {
    setIsLoading(true);
    setErrorFetching(null);
    try {
      const fetchedUsers = await getAllUsers();
      setUsers(fetchedUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      setErrorFetching("No se pudieron cargar los usuarios. Inténtalo de nuevo más tarde.");
      toast({
        title: "Error al cargar usuarios",
        description: (error as Error).message || "Ocurrió un error desconocido.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleEditUser = (user: User) => {
    setCurrentUserToEdit(user);
    form.reset({
      role: user.role,
      isVerified: user.role === 'provider' ? user.isVerified : undefined,
      isDonor: user.isDonor,
    });
    setIsModalOpen(true);
  };

  const watchedRole = form.watch("role");

  useEffect(() => {
    if (currentUserToEdit) {
        const currentRoleIsProvider = currentUserToEdit.role === 'provider';
        const newRoleIsProvider = watchedRole === 'provider';

        if (newRoleIsProvider && !currentRoleIsProvider) {
            if (form.getValues("isVerified") === undefined) {
                 form.setValue("isVerified", false);
            }
        }
    }
  }, [watchedRole, currentUserToEdit, form]);


  const onSubmit: SubmitHandler<UserEditFormData> = async (data) => {
    if (!currentUserToEdit) return;
    setIsSubmitting(true);

    const updateData: Partial<User> = {
      role: data.role,
      isDonor: data.isDonor,
    };

    if (data.role === 'provider') {
      updateData.isVerified = data.isVerified ?? false;
    } else {
      updateData.isVerified = false; 
    }

    try {
      const result = await updateUserAdminDetails(currentUserToEdit.id, updateData);
      if (result.success) {
        toast({ title: "Usuario Actualizado", description: "Los detalles del usuario han sido actualizados." });
        setIsModalOpen(false);
        fetchUsers();
      } else {
        toast({
          title: "Error al Actualizar",
          description: result.error || "Ocurrió un error desconocido.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error Inesperado",
        description: (error as Error).message || "Ocurrió un error al procesar la solicitud.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };


  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <UsersIcon className="h-8 w-8" />
          Gestión de Usuarios
        </h1>
        <p className="text-muted-foreground">
          Administra los usuarios de la plataforma, sus roles y estados. Actualmente hay {users.length} usuario(s).
        </p>
      </header>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Editar Usuario: {currentUserToEdit?.displayName || currentUserToEdit?.email}</DialogTitle>
            <DialogModalDescription>
              Modifica el rol y otros atributos del usuario. Email: {currentUserToEdit?.email}
            </DialogModalDescription>
          </DialogHeader>
          {currentUserToEdit && (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-2">
                <FormField
                  control={form.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rol del Usuario</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecciona un rol" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="client">Cliente</SelectItem>
                          <SelectItem value="provider">Proveedor</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {watchedRole === 'provider' && (
                  <FormField
                    control={form.control}
                    name="isVerified"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                        <div className="space-y-0.5">
                          <FormLabel>Proveedor Verificado</FormLabel>
                          <FormDescription>
                            Indica si el perfil del proveedor ha sido verificado.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="isDonor"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>Es Donador</FormLabel>
                        <FormDescription>
                          Indica si el usuario ha realizado donaciones.
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <DialogFooter className="pt-4">
                  <DialogClose asChild>
                    <Button type="button" variant="outline" disabled={isSubmitting}>Cancelar</Button>
                  </DialogClose>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Guardar Cambios
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle>Listado de Usuarios</CardTitle>
          <PageCardDescription>
            Visualiza y gestiona los usuarios registrados en ServiLocal.
          </PageCardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="ml-2">Cargando usuarios...</p>
            </div>
          ) : errorFetching ? (
             <div className="text-center py-10 text-destructive">
                <p className="text-xl font-semibold">{errorFetching}</p>
             </div>
          ) : users.length === 0 ? (
             <div className="text-center py-10 text-muted-foreground">
                <Info className="mx-auto h-12 w-12 mb-4" />
                <p className="text-xl font-semibold">No hay usuarios registrados.</p>
                <p>Cuando los usuarios se registren, aparecerán aquí.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nombre</TableHead>
                  <TableHead className="hidden sm:table-cell">Email</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead className="text-center hidden md:table-cell">Verificado (Proveedor)</TableHead>
                  <TableHead className="text-center hidden md:table-cell">Donador</TableHead>
                  <TableHead className="hidden lg:table-cell">Registrado</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.displayName || user.email?.split('@')[0] || 'N/A'}</TableCell>
                    <TableCell className="hidden sm:table-cell text-muted-foreground">{user.email}</TableCell>
                    <TableCell><RoleBadge role={user.role} /></TableCell>
                    <TableCell className="text-center hidden md:table-cell">
                      {user.role === 'provider' ? (
                        user.isVerified ? <CheckCircle className="h-5 w-5 text-green-500 inline-block" /> : <XCircle className="h-5 w-5 text-red-500 inline-block" />
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center hidden md:table-cell">
                      {user.isDonor ? <CheckCircle className="h-5 w-5 text-green-500 inline-block" /> : <XCircle className="h-5 w-5 text-red-500 inline-block" />}
                    </TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">
                      {formatDate(user.createdAt as unknown as string)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" onClick={() => handleEditUser(user)} disabled={user.email === "admin@servilocal.com"}>
                         <Edit className="h-4 w-4 mr-1 md:mr-1.5" />
                         <span className="hidden md:inline">Editar</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

