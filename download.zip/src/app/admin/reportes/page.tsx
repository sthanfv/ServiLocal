
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { ShieldAlert } from "lucide-react";

export default function AdminReportesPage() {
  return (
    <div className="space-y-6">
       <header>
        <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <ShieldAlert className="h-8 w-8" />
          Gestión de Reportes
        </h1>
        <p className="text-muted-foreground">
          Revisa y gestiona los reportes enviados por los usuarios sobre contenido o comportamiento inadecuado.
        </p>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Listado de Reportes</CardTitle>
          <CardDescription>
            Reportes nuevos, en revisión y resueltos.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">La tabla de reportes, filtros y acciones de gestión se implementarán aquí.</p>
          {/* TODO: Implementar tabla de reportes, filtros y acciones */}
        </CardContent>
      </Card>
    </div>
  );
}
