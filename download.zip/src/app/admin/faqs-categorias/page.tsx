
"use client";

import { useEffect, useState } from "react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import {
  createCategoryFaq,
  deleteCategoryFaq,
  getAllCategoryFaqsAdmin,
  updateCategoryFaq,
  getActiveServiceCategories, // To populate category selector
} from "@/app/actions";
import type { CategoryFaq, ServiceCategory } from "@/lib/types";
import { CategoryFaqSchema, type CategoryFaqFormData } from "@/lib/schemas";
import { HelpCircle, PlusCircle, Edit, Trash2, Loader2, AlertTriangle, Info } from "lucide-react";

export default function AdminFaqsCategoriasPage() {
  const { toast } = useToast();
  const [faqs, setFaqs] = useState<CategoryFaq[]>([]);
  const [serviceCategories, setServiceCategories] = useState<ServiceCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentFaq, setCurrentFaq] = useState<CategoryFaq | null>(null);
  const [errorFetching, setErrorFetching] = useState<string | null>(null);

  const form = useForm<CategoryFaqFormData>({
    resolver: zodResolver(CategoryFaqSchema),
    defaultValues: {
      categoryId: "",
      question: "",
      answer: "",
      isActive: true,
      displayOrder: 0,
    },
  });

  const fetchFaqsAndCategories = async () => {
    setIsLoading(true);
    setErrorFetching(null);
    try {
      const [fetchedFaqs, fetchedCategories] = await Promise.all([
        getAllCategoryFaqsAdmin(),
        getActiveServiceCategories(),
      ]);
      setFaqs(fetchedFaqs);
      setServiceCategories(fetchedCategories);
    } catch (error) {
      console.error("Error fetching FAQs or categories:", error);
      setErrorFetching("No se pudieron cargar los datos. Inténtalo de nuevo más tarde.");
      toast({
        title: "Error al cargar datos",
        description: (error as Error).message || "Ocurrió un error desconocido.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFaqsAndCategories();
  }, []);

  const handleCreateNew = () => {
    setCurrentFaq(null);
    form.reset({
      categoryId: "",
      question: "",
      answer: "",
      isActive: true,
      displayOrder: faqs.length > 0 ? Math.max(...faqs.map(f => f.displayOrder)) + 10 : 0,
    });
    setIsModalOpen(true);
  };

  const handleEdit = (faq: CategoryFaq) => {
    setCurrentFaq(faq);
    form.reset({
      categoryId: faq.categoryId,
      question: faq.question,
      answer: faq.answer,
      isActive: faq.isActive,
      displayOrder: faq.displayOrder,
    });
    setIsModalOpen(true);
  };

  const onSubmit: SubmitHandler<CategoryFaqFormData> = async (data) => {
    setIsSubmitting(true);
    try {
      let result;
      if (currentFaq) {
        result = await updateCategoryFaq(currentFaq.id, data);
        toast({ title: "FAQ Actualizada", description: "La FAQ ha sido actualizada exitosamente." });
      } else {
        result = await createCategoryFaq(data);
        toast({ title: "FAQ Creada", description: "La nueva FAQ ha sido creada exitosamente." });
      }

      if (result.success) {
        setIsModalOpen(false);
        fetchFaqsAndCategories(); // Re-fetch
      } else {
        toast({
          title: currentFaq ? "Error al Actualizar" : "Error al Crear",
          description: result.error || "Ocurrió un error desconocido.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error Inesperado",
        description: (error as Error).message || "Ocurrió un error al procesar la solicitud.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (faqId: string) => {
    try {
      const result = await deleteCategoryFaq(faqId);
      if (result.success) {
        toast({ title: "FAQ Eliminada", description: "La FAQ ha sido eliminada exitosamente." });
        fetchFaqsAndCategories(); // Re-fetch
      } else {
        toast({
          title: "Error al Eliminar",
          description: result.error || "Ocurrió un error desconocido.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error Inesperado",
        description: (error as Error).message || "Ocurrió un error al procesar la solicitud.",
        variant: "destructive",
      });
    }
  };
  
  const getCategoryName = (categoryId: string) => {
    return serviceCategories.find(cat => cat.id === categoryId)?.name || "Desconocida";
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <HelpCircle className="h-8 w-8" />
            Gestión de FAQs por Categoría
          </h1>
          <p className="text-muted-foreground">
            Crea y administra preguntas frecuentes para cada categoría de servicio.
          </p>
        </div>
        <Button onClick={handleCreateNew} className="w-full sm:w-auto">
          <PlusCircle className="mr-2 h-5 w-5" />
          Crear Nueva FAQ
        </Button>
      </header>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{currentFaq ? "Editar FAQ" : "Crear Nueva FAQ"}</DialogTitle>
            <DialogDescription>
              {currentFaq ? "Modifica los detalles de la FAQ." : "Completa el formulario para añadir una nueva FAQ."}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 p-1">
              <FormField
                control={form.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Categoría de Servicio</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona una categoría" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {serviceCategories.map((category) => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="question"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pregunta</FormLabel>
                    <FormControl>
                      <Input placeholder="Ej: ¿Cuánto tiempo tarda el servicio?" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="answer"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Respuesta</FormLabel>
                    <FormControl>
                      <Textarea placeholder="La respuesta detallada a la pregunta..." {...field} rows={5} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="displayOrder"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Orden de Visualización</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="0" {...field} />
                    </FormControl>
                    <FormDescription>
                      Número menor aparece primero dentro de su categoría.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Activa</FormLabel>
                      <FormDescription>
                        Indica si la FAQ estará visible.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <DialogFooter className="pt-4">
                 <DialogClose asChild>
                    <Button type="button" variant="outline" disabled={isSubmitting}>Cancelar</Button>
                 </DialogClose>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  {currentFaq ? "Guardar Cambios" : "Crear FAQ"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle>Listado de FAQs por Categoría</CardTitle>
          <CardDescription>
            Administra todas las FAQs. Actualmente hay {faqs.length} FAQ(s).
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="ml-2">Cargando FAQs...</p>
            </div>
          ) : errorFetching ? (
             <div className="text-center py-10 text-destructive">
                <AlertTriangle className="mx-auto h-12 w-12 mb-4" />
                <p className="text-xl font-semibold">{errorFetching}</p>
             </div>
          ) : faqs.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Info className="mx-auto h-12 w-12 mb-4" />
              <p className="text-xl font-semibold">No hay FAQs creadas.</p>
              <p>Empieza creando una nueva FAQ para ayudar a los usuarios.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Categoría</TableHead>
                  <TableHead>Pregunta</TableHead>
                  <TableHead className="hidden md:table-cell max-w-xs truncate">Respuesta (extracto)</TableHead>
                  <TableHead className="text-center">Activa</TableHead>
                  <TableHead className="text-center hidden sm:table-cell">Orden</TableHead>
                  <TableHead className="text-right w-[120px]">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {faqs.map((faq) => (
                  <TableRow key={faq.id}>
                    <TableCell className="font-medium">{getCategoryName(faq.categoryId)}</TableCell>
                    <TableCell className="font-medium max-w-sm truncate" title={faq.question}>{faq.question}</TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground max-w-xs truncate" title={faq.answer}>
                        {faq.answer}
                    </TableCell>
                    <TableCell className="text-center">
                      <Switch checked={faq.isActive} disabled className="opacity-100 scale-75" />
                    </TableCell>
                    <TableCell className="text-center hidden sm:table-cell">{faq.displayOrder}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="outline" size="icon" onClick={() => handleEdit(faq)} title="Editar">
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Editar FAQ</span>
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="icon" title="Eliminar">
                            <Trash2 className="h-4 w-4" />
                             <span className="sr-only">Eliminar FAQ</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>¿Estás seguro de eliminar esta FAQ?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Esta acción no se puede deshacer. Esto eliminará permanentemente la FAQ:
                              <strong className="block mt-1 truncate" title={faq.question}>"{faq.question}"</strong>.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDelete(faq.id)}>
                              Sí, eliminar
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
