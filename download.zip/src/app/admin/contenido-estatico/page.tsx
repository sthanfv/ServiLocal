
"use client";

import { useEffect, useState } from "react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { getSiteContent, updateSiteContent } from "@/app/actions";
import type { SiteContent } from "@/lib/types";
import { SiteContentSchema, type SiteContentFormData } from "@/lib/schemas";
import { FileText, Loader2, AlertTriangle, Info, Save } from "lucide-react";

// Define las páginas estáticas que se pueden editar
const editablePages = [
  { id: "terminos-y-condiciones", name: "Términos y Condiciones" },
  { id: "politica-de-privacidad", name: "Política de Privacidad" },
  { id: "consejos-contratacion", name: "Consejos de Contratación" },
  { id: "guia-proveedores", name: "Guía para Proveedores" },
  { id: "apoyanos-intro", name: "Apóyanos (Introducción)" },
  { id: "convertirse-en-proveedor", name: "Conviértete en Proveedor (Info)" },
  // Agrega más páginas aquí si es necesario
];

export default function AdminContenidoEstaticoPage() {
  const { toast } = useToast();
  const [selectedPageId, setSelectedPageId] = useState<string | null>(null);
  const [currentContent, setCurrentContent] = useState<SiteContent | null>(null);
  const [isLoadingPage, setIsLoadingPage] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorFetching, setErrorFetching] = useState<string | null>(null);

  const form = useForm<SiteContentFormData>({
    resolver: zodResolver(SiteContentSchema),
    defaultValues: {
      title: "",
      content: "",
    },
  });

  useEffect(() => {
    if (selectedPageId) {
      const fetchContent = async () => {
        setIsLoadingPage(true);
        setErrorFetching(null);
        form.reset({ title: "", content: "" }); // Reset form before fetching
        try {
          const contentData = await getSiteContent(selectedPageId);
          if (contentData) {
            setCurrentContent(contentData);
            form.reset({
              title: contentData.title,
              content: contentData.content,
            });
          } else {
            // Si no hay contenido, inicializamos con el nombre de la página editable como título
            const pageDetails = editablePages.find(p => p.id === selectedPageId);
            setCurrentContent(null); // No existing content in DB
            form.reset({
              title: pageDetails?.name || "Nuevo Contenido",
              content: "<p>Empieza a escribir el contenido aquí...</p>",
            });
             toast({
              title: "Contenido no encontrado",
              description: "Esta página aún no tiene contenido guardado. Puedes crearlo ahora.",
              variant: "default",
            });
          }
        } catch (error) {
          console.error("Error fetching site content:", error);
          setErrorFetching("No se pudo cargar el contenido de la página.");
          toast({
            title: "Error al Cargar Contenido",
            description: (error as Error).message || "Ocurrió un error.",
            variant: "destructive",
          });
        } finally {
          setIsLoadingPage(false);
        }
      };
      fetchContent();
    } else {
      setCurrentContent(null);
      form.reset({ title: "", content: "" });
    }
  }, [selectedPageId, form, toast]);

  const onSubmit: SubmitHandler<SiteContentFormData> = async (data) => {
    if (!selectedPageId) {
      toast({ title: "Error", description: "No se ha seleccionado ninguna página.", variant: "destructive" });
      return;
    }
    setIsSubmitting(true);
    try {
      const result = await updateSiteContent(selectedPageId, data.title, data.content);
      if (result.success) {
        toast({ title: "Contenido Actualizado", description: "La página ha sido actualizada exitosamente." });
        // Re-fetch content to update "Last Updated" and reflect changes
        const updatedContent = await getSiteContent(selectedPageId);
        if (updatedContent) setCurrentContent(updatedContent);
      } else {
        toast({
          title: "Error al Actualizar",
          description: result.error || "Ocurrió un error desconocido.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error Inesperado",
        description: (error as Error).message || "Ocurrió un error al procesar la solicitud.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <FileText className="h-8 w-8" />
          Gestión de Contenido Estático
        </h1>
        <p className="text-muted-foreground">
          Edita el contenido de las páginas estáticas como Términos y Condiciones, Política de Privacidad, etc.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Editor de Contenido</CardTitle>
          <CardDescription>
            Selecciona una página de la lista para ver o modificar su contenido.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Select
            onValueChange={(value) => setSelectedPageId(value)}
            defaultValue={selectedPageId || ""}
          >
            <SelectTrigger className="w-full md:w-[300px]">
              <SelectValue placeholder="Selecciona una página para editar" />
            </SelectTrigger>
            <SelectContent>
              {editablePages.map((page) => (
                <SelectItem key={page.id} value={page.id}>
                  {page.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {isLoadingPage && (
            <div className="flex justify-center items-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="ml-2">Cargando contenido...</p>
            </div>
          )}

          {errorFetching && !isLoadingPage && (
            <div className="text-center py-10 text-destructive">
              <AlertTriangle className="mx-auto h-12 w-12 mb-4" />
              <p className="text-xl font-semibold">{errorFetching}</p>
            </div>
          )}

          {!isLoadingPage && !errorFetching && selectedPageId && (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {currentContent?.lastUpdatedAt && (
                  <p className="text-sm text-muted-foreground">
                    Última actualización: {new Date(currentContent.lastUpdatedAt as any).toLocaleString('es-ES')}
                  </p>
                )}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Título de la Página</FormLabel>
                      <FormControl>
                        <Input placeholder="Título principal de la página" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contenido de la Página (HTML)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Ingresa el contenido en formato HTML..."
                          {...field}
                          rows={15}
                          className="font-mono text-sm"
                        />
                      </FormControl>
                      <FormDescription>
                        Puedes usar etiquetas HTML para dar formato al texto (ej: &lt;p&gt;, &lt;h2&gt;, &lt;ul&gt;, &lt;li&gt;, &lt;strong&gt;).
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={isSubmitting || isLoadingPage} className="w-full sm:w-auto">
                  {isSubmitting ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="mr-2 h-4 w-4" />
                  )}
                  Guardar Cambios
                </Button>
              </form>
            </Form>
          )}
          {!isLoadingPage && !selectedPageId && (
             <div className="text-center py-10 text-muted-foreground">
                <Info className="mx-auto h-12 w-12 mb-4" />
                <p className="text-xl font-semibold">Selecciona una página</p>
                <p>Elige una página de la lista de arriba para comenzar a editar su contenido.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
