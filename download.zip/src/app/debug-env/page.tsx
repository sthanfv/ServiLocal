
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function DebugEnvPage() {
  const firebaseApiKey = process.env.NEXT_PUBLIC_FIREBASE_API_KEY;
  const firebaseAuthDomain = process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN;
  const firebaseProjectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
  const firebaseStorageBucket = process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET;
  const firebaseMessagingSenderId = process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID;
  const firebaseAppId = process.env.NEXT_PUBLIC_FIREBASE_APP_ID;

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Debug Firebase Environment Variables (Client-Side)</CardTitle>
          <CardDescription>
            Esta página muestra los valores de las variables de entorno de Firebase
            tal como se leen en el lado del cliente.
            <strong className="text-destructive"> Elimina esta página o su contenido sensible después de depurar.</strong>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <h3 className="font-semibold">NEXT_PUBLIC_FIREBASE_API_KEY:</h3>
            <p className="text-sm text-muted-foreground break-all">{firebaseApiKey || "No definido"}</p>
          </div>
          <div>
            <h3 className="font-semibold">NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN:</h3>
            <p className="text-sm text-muted-foreground break-all">{firebaseAuthDomain || "No definido"}</p>
          </div>
          <div>
            <h3 className="font-semibold">NEXT_PUBLIC_FIREBASE_PROJECT_ID:</h3>
            <p className="text-sm text-muted-foreground break-all">{firebaseProjectId || "No definido"}</p>
          </div>
          <div>
            <h3 className="font-semibold">NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET:</h3>
            <p className="text-sm text-muted-foreground break-all">{firebaseStorageBucket || "No definido"}</p>
          </div>
          <div>
            <h3 className="font-semibold">NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID:</h3>
            <p className="text-sm text-muted-foreground break-all">{firebaseMessagingSenderId || "No definido"}</p>
          </div>
          <div>
            <h3 className="font-semibold">NEXT_PUBLIC_FIREBASE_APP_ID:</h3>
            <p className="text-sm text-muted-foreground break-all">{firebaseAppId || "No definido"}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
