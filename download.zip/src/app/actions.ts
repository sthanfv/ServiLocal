
"use server";

import { db } from "@/lib/firebase";
import { collection, doc, getDoc, getDocs, query, where, orderBy, limit, startAfter, addDoc, updateDoc, deleteDoc, serverTimestamp, runTransaction, setDoc } from "firebase/firestore";
import type { SiteContent, DonationMethod, ServiceCategory, Service, Review, User, ProviderProfile, PublicServiceRequest, CategoryFaq, Report, AnalyzeReviewInput } from "@/lib/types"; // Import AnalyzeReviewInput type
import type { ServiceCategoryFormData, SiteContentFormData, DonationMethodFormData, CategoryFaqFormData } from "@/lib/schemas";
import { revalidatePath } from "next/cache";
import { analyzeReview } from '@/ai/flows/analyze-review-flow'; // Import AI review analysis function

// Helper function to convert Firestore document to plain object
function docToPlainObject<T>(docSnap: any): T {
  const data = docSnap.data();
  return {
    id: docSnap.id,
    ...data,
    // Convert Timestamps to string or number if necessary, or handle on client
    ...(data?.createdAt && { createdAt: data.createdAt.toDate().toISOString() }),
    ...(data?.updatedAt && { updatedAt: data.updatedAt.toDate().toISOString() }),
    ...(data?.lastUpdatedAt && { lastUpdatedAt: data.lastUpdatedAt.toDate().toISOString() }),
    ...(data?.lastMessageTimestamp && { lastMessageTimestamp: data.lastMessageTimestamp.toDate().toISOString() }),
    ...(data?.aiAnalyzedAt && { aiAnalyzedAt: data.aiAnalyzedAt.toDate().toISOString() }), // Handle new aiAnalyzedAt field
  } as T;
}


// A. Authentication related actions (mostly handled by Firebase Auth SDK on client, but user doc creation could be an action if not using triggers)
// Example: Create user document after successful Firebase Auth registration (if not using onUserCreate trigger)
export async function createUserDocument(userId: string, email: string, displayName?: string, role: 'client' | 'provider' = 'client') {
  try {
    const userRef = doc(db, "users", userId);
    await setDoc(userRef, {
      email,
      displayName: displayName || email.split('@')[0],
      role,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      isVerified: false, // Default to false, admin/system can change this for providers
      isDonor: false,
      ...(role === 'provider' && { 
        providerProfile: {
          businessName: "",
          providerDescription: "",
          serviceCategoriesText: "",
          serviceLocations: "",
          contactPhone: "",
          websiteUrl: "",
          portfolioImages: [],
          averageRating: 0,
          reviewCount: 0,
        }
      })
    });
    revalidatePath('/perfil'); // Potentially revalidate relevant paths
    return { success: true, userId };
  } catch (error) {
    console.error("Error creating user document: ", error);
    return { success: false, error: (error as Error).message };
  }
}


// B. Static Page Content
export async function getSiteContent(pageId: string): Promise<SiteContent | null> {
  try {
    const docRef = doc(db, "siteContent", pageId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docToPlainObject<SiteContent>(docSnap);
    }
    return null;
  } catch (error) {
    console.error("Error fetching site content:", error);
    return null; // Or throw error
  }
}

export async function updateSiteContent(pageId: string, title: string, content: string): Promise<{ success: boolean; error?: string }> {
  try {
    const docRef = doc(db, "siteContent", pageId);
    await setDoc(docRef, { // Use setDoc with merge: true or updateDoc if you are sure doc exists
      title,
      content,
      lastUpdatedAt: serverTimestamp(),
    }, { merge: true }); // merge: true will create the doc if it doesn't exist, or update if it does.

    // Revalidate the specific static page path and also the admin page
    revalidatePath(`/${pageId}`); // e.g., /terminos-y-condiciones
    revalidatePath("/admin/contenido-estatico");
    
    // For pages like "apoyanos-intro", the actual path might be different.
    // Consider a mapping if pageId doesn't directly map to path.
    if (pageId === "apoyanos-intro") revalidatePath("/apoyanos");
    if (pageId === "convertirse-en-proveedor") revalidatePath("/convertirse-en-proveedor");


    return { success: true };
  } catch (error) {
    console.error("Error updating site content:", error);
    return { success: false, error: (error as Error).message };
  }
}


// C. "Apóyanos" Page & Admin Donation Methods
export async function getActiveDonationMethods(): Promise<DonationMethod[]> {
  try {
    const q = query(collection(db, "donationMethods"), where("isActive", "==", true), orderBy("displayOrder"));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<DonationMethod>(docSnap));
  } catch (error) {
    console.error("Error fetching active donation methods:", error);
    return [];
  }
}

export async function getAllDonationMethods(): Promise<DonationMethod[]> {
  try {
    const q = query(collection(db, "donationMethods"), orderBy("displayOrder", "asc"));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<DonationMethod>(docSnap));
  } catch (error) {
    console.error("Error fetching all donation methods:", error);
    return [];
  }
}

export async function getDonationMethod(id: string): Promise<DonationMethod | null> {
  try {
    const docRef = doc(db, "donationMethods", id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docToPlainObject<DonationMethod>(docSnap);
    }
    return null;
  } catch (error) {
    console.error("Error fetching donation method:", error);
    return null;
  }
}

export async function createDonationMethod(data: DonationMethodFormData): Promise<{ success: boolean; methodId?: string; error?: string }> {
  try {
    const newMethodRef = await addDoc(collection(db, "donationMethods"), {
      ...data,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    revalidatePath("/admin/metodos-donacion");
    revalidatePath("/apoyanos");
    return { success: true, methodId: newMethodRef.id };
  } catch (error) {
    console.error("Error creating donation method:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function updateDonationMethod(id: string, data: Partial<DonationMethodFormData>): Promise<{ success: boolean; error?: string }> {
  try {
    const methodRef = doc(db, "donationMethods", id);
    await updateDoc(methodRef, {
      ...data,
      updatedAt: serverTimestamp(),
    });
    revalidatePath("/admin/metodos-donacion");
    revalidatePath("/apoyanos");
    return { success: true };
  } catch (error) {
    console.error("Error updating donation method:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function deleteDonationMethod(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    await deleteDoc(doc(db, "donationMethods", id));
    revalidatePath("/admin/metodos-donacion");
    revalidatePath("/apoyanos");
    return { success: true };
  } catch (error) {
    console.error("Error deleting donation method:", error);
    return { success: false, error: (error as Error).message };
  }
}


// D. User Profiles & Management
export async function getUserProfile(userId: string): Promise<User | null> {
  try {
    const userRef = doc(db, "users", userId);
    const docSnap = await getDoc(userRef);
    if (docSnap.exists()) {
      return docToPlainObject<User>(docSnap);
    }
    return null;
  } catch (error) {
    console.error("Error fetching user profile:", error);
    return null;
  }
}

export async function getAllUsers(): Promise<User[]> {
  try {
    // Consider adding orderBy and pagination for larger user bases
    const q = query(collection(db, "users"), orderBy("createdAt", "desc")); 
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<User>(docSnap));
  } catch (error) {
    console.error("Error fetching all users:", error);
    return [];
  }
}

export async function updateProviderProfile(userId: string, data: Partial<ProviderProfile>) {
  try {
    const userRef = doc(db, "users", userId);
    // Construct the update object carefully to only update providerProfile fields
    const updateData: { [key: string]: any } = {};
    for (const key in data) {
      if (Object.prototype.hasOwnProperty.call(data, key)) {
        updateData[`providerProfile.${key}`] = (data as any)[key];
      }
    }
    updateData.updatedAt = serverTimestamp();
    
    await updateDoc(userRef, updateData);
    revalidatePath(`/perfil`);
    revalidatePath(`/dashboard/provider/perfil/editar`);
    return { success: true };
  } catch (error) {
    console.error("Error updating provider profile:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function updateUserAdminDetails(userId: string, data: Partial<Pick<User, 'role' | 'isVerified' | 'isDonor'>>) {
  try {
    const userRef = doc(db, "users", userId);
    // The 'data' object should be prepared by the client to only include 'role', 'isVerified', 'isDonor'.
    // The client-side logic in AdminUsuariosPage ensures 'isVerified' is handled correctly based on 'role'.
    const updatePayload: { [key: string]: any } = { ...data };
    updatePayload.updatedAt = serverTimestamp();

    await updateDoc(userRef, updatePayload);
    revalidatePath("/admin/usuarios"); // Revalidate the users list page
    // Revalidate general profile page; specific user profile pages might need dynamic path revalidation.
    revalidatePath(`/perfil`); 
    return { success: true };
  } catch (error) {
    console.error("Error updating user admin details:", error);
    return { success: false, error: (error as Error).message };
  }
}

// E. Service Categories (Admin)
export async function createServiceCategory(data: ServiceCategoryFormData): Promise<{ success: boolean; categoryId?: string; error?: string }> {
  try {
    const newCategoryRef = await addDoc(collection(db, "serviceCategories"), {
      ...data,
      slug: data.slug.toLowerCase(), // Ensure slug is lowercase
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    revalidatePath("/admin/categorias");
    return { success: true, categoryId: newCategoryRef.id };
  } catch (error) {
    console.error("Error creating service category:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function getAllServiceCategories(): Promise<ServiceCategory[]> {
  try {
    const q = query(collection(db, "serviceCategories"), orderBy("name", "asc"));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<ServiceCategory>(docSnap));
  } catch (error) {
    console.error("Error fetching all service categories:", error);
    return [];
  }
}

export async function getServiceCategory(categoryId: string): Promise<ServiceCategory | null> {
  try {
    const docRef = doc(db, "serviceCategories", categoryId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docToPlainObject<ServiceCategory>(docSnap);
    }
    return null;
  } catch (error) {
    console.error("Error fetching service category:", error);
    return null;
  }
}

export async function updateServiceCategory(categoryId: string, data: Partial<ServiceCategoryFormData>): Promise<{ success: boolean; error?: string }> {
  try {
    const categoryRef = doc(db, "serviceCategories", categoryId);
    const updateData: any = { ...data, updatedAt: serverTimestamp() };
    if (data.slug) {
      updateData.slug = data.slug.toLowerCase();
    }
    await updateDoc(categoryRef, updateData);
    revalidatePath("/admin/categorias");
    // Optional: revalidatePath(`/admin/categorias/${categoryId}/edit`); // If you have an edit page
    return { success: true };
  } catch (error) {
    console.error("Error updating service category:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function deleteServiceCategory(categoryId: string): Promise<{ success: boolean; error?: string }> {
  try {
    // For now, direct delete. Consider soft delete (isActive = false) in the future.
    await deleteDoc(doc(db, "serviceCategories", categoryId));
    revalidatePath("/admin/categorias");
    return { success: true };
  } catch (error) {
    console.error("Error deleting service category:", error);
    return { success: false, error: (error as Error).message };
  }
}

// F. Services (General & Provider)
export async function getActiveServiceCategories(): Promise<ServiceCategory[]> {
  try {
    // This query requires a composite index on isActive (asc) and name (asc)
    const q = query(collection(db, "serviceCategories"), where("isActive", "==", true), orderBy("name"));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<ServiceCategory>(docSnap));
  } catch (error) {
    console.error("Error fetching active service categories:", error);
    // If error includes "firestore/failed-precondition" and mentions missing index,
    // Firebase console log will provide a link to create it.
    return [];
  }
}

export async function createService(providerId: string, providerDisplayName: string, serviceData: Omit<Service, 'id' | 'providerId' | 'providerDisplayName' | 'status' | 'createdAt' | 'updatedAt'>) {
  try {
    const newServiceRef = await addDoc(collection(db, "services"), {
      ...serviceData,
      providerId,
      providerDisplayName,
      status: 'pending_approval',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    revalidatePath('/dashboard/provider/servicios');
    return { success: true, serviceId: newServiceRef.id };
  } catch (error) {
    console.error("Error creating service:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function updateService(serviceId: string, data: Partial<Omit<Service, 'id' | 'createdAt'>>) {
   try {
    const serviceRef = doc(db, "services", serviceId);
    await updateDoc(serviceRef, {
      ...data,
      updatedAt: serverTimestamp(),
    });
    revalidatePath(`/dashboard/provider/servicios`);
    revalidatePath(`/dashboard/provider/servicios/${serviceId}/editar`);
    revalidatePath(`/servicios/${serviceId}`);
    return { success: true };
  } catch (error) {
    console.error("Error updating service:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function deleteService(serviceId: string) {
  try {
    // Option 1: Soft delete by changing status
    const serviceRef = doc(db, "services", serviceId);
    await updateDoc(serviceRef, {
      status: 'archived',
      updatedAt: serverTimestamp(),
    });
    // Option 2: Hard delete
    // await deleteDoc(doc(db, "services", serviceId));
    revalidatePath('/dashboard/provider/servicios');
    return { success: true };
  } catch (error) {
    console.error("Error deleting service:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function getProviderServices(providerId: string): Promise<Service[]> {
  try {
    const q = query(collection(db, "services"), where("providerId", "==", providerId), orderBy("createdAt", "desc"));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<Service>(docSnap));
  } catch (error) {
    console.error("Error fetching provider services:", error);
    return [];
  }
}

interface ServiceFilters {
  keyword?: string;
  categoryId?: string;
  locationText?: string;
  minRating?: number; // This would require filtering on provider's averageRating
}

export async function getListedServices(filters: ServiceFilters, lastVisibleId?: string): Promise<{services: Service[], nextPageCursor?: string}> {
  try {
    let q = query(collection(db, "services"), where("status", "==", "active"), orderBy("createdAt", "desc"));
    // This query (status asc, createdAt desc) requires a composite index.

    if (filters.categoryId && filters.categoryId !== "all") {
      q = query(q, where("categoryId", "==", filters.categoryId));
      // Adding this filter might require another composite index:
      // status (asc), categoryId (asc), createdAt (desc)
    }
    // Keyword search usually requires a dedicated search service like Algolia or Typesense.
    // Firestore doesn't support native partial text search efficiently across multiple fields.
    // If filters.keyword is present, you'd typically query your search service here.
    // For this example, we'll assume keyword search is handled separately or not implemented directly in this Firestore query.


    const pageLimit = 10;
    if (lastVisibleId) {
      const lastVisibleDoc = await getDoc(doc(db, "services", lastVisibleId));
      if (lastVisibleDoc.exists()) {
        q = query(q, startAfter(lastVisibleDoc));
      }
    }
    q = query(q, limit(pageLimit));
    
    const querySnapshot = await getDocs(q);
    const services = querySnapshot.docs.map(docSnap => docToPlainObject<Service>(docSnap));
    
    let nextPageCursor: string | undefined = undefined;
    if (querySnapshot.docs.length === pageLimit) {
      nextPageCursor = querySnapshot.docs[querySnapshot.docs.length - 1]?.id;
    }

    return { services, nextPageCursor };
  } catch (error) {
    console.error("Error fetching listed services:", error);
    return { services: [], nextPageCursor: undefined };
  }
}

export async function getServiceDetails(serviceId: string): Promise<{service: Service, provider: User } | null> {
  try {
    const serviceRef = doc(db, "services", serviceId);
    const serviceSnap = await getDoc(serviceRef);

    if (!serviceSnap.exists()) return null;
    const serviceData = docToPlainObject<Service>(serviceSnap);

    const providerSnap = await getDoc(doc(db, "users", serviceData.providerId));
    if (!providerSnap.exists()) return { service: serviceData, provider: null as any }; // Or handle provider not found
    
    const providerData = docToPlainObject<User>(providerSnap);
    
    return { service: serviceData, provider: providerData };
  } catch (error) {
    console.error("Error fetching service details:", error);
    return null;
  }
}

// G. Calificaciones y Reseñas
export async function createReview(
  clientId: string, 
  clientDisplayName: string, 
  reviewData: Omit<Review, 'id' | 'clientId' | 'clientDisplayName' | 'createdAt' | 'aiAnalysis' | 'aiAnalyzedAt'>
) {
  try {
    const newReviewRef = await addDoc(collection(db, "reviews"), {
      ...reviewData,
      clientId,
      clientDisplayName,
      createdAt: serverTimestamp(),
    });

    // Perform AI analysis after review is created
    try {
      const aiInput: AnalyzeReviewInput = {
        reviewText: reviewData.comment,
        reviewRating: reviewData.rating,
      };

      if (reviewData.serviceId) {
        const serviceRef = doc(db, "services", reviewData.serviceId);
        const serviceSnap = await getDoc(serviceRef);
        if (serviceSnap.exists()) {
          const serviceDocData = serviceSnap.data() as Service;
          aiInput.serviceCategory = serviceDocData.categoryName;
        }
      }
      
      const analysisResult = await analyzeReview(aiInput);

      await updateDoc(newReviewRef, {
        aiAnalysis: analysisResult,
        aiAnalyzedAt: serverTimestamp(),
      });
      console.log(`AI analysis completed for review ${newReviewRef.id}`);

    } catch (aiError) {
      console.error(`Error during AI analysis for review ${newReviewRef.id}:`, aiError);
      // The review is created, but AI analysis failed. We can proceed or log this specific error.
      // Optionally, update the review to indicate analysis failure.
      // For now, we just log it. The document won't have aiAnalysis or aiAnalyzedAt.
    }

    revalidatePath(`/servicios`); 
    if (reviewData.providerId) {
      revalidatePath(`/proveedores/${reviewData.providerId}`); 
    }
    if (reviewData.serviceId) {
        revalidatePath(`/servicios/${reviewData.serviceId}`);
    }
    
    return { success: true, reviewId: newReviewRef.id };
  } catch (error) {
    console.error("Error creating review:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function getReviewsForProvider(providerId: string): Promise<Review[]> {
  try {
    const q = query(collection(db, "reviews"), where("providerId", "==", providerId), orderBy("createdAt", "desc"));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<Review>(docSnap));
  } catch (error) {
    console.error("Error fetching reviews for provider:", error);
    return [];
  }
}


// H. Category FAQs
export async function getCategoryFaqs(categoryId: string): Promise<CategoryFaq[]> {
  try {
    const q = query(collection(db, "categoryFaqs"), where("categoryId", "==", categoryId), where("isActive", "==", true), orderBy("displayOrder"));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<CategoryFaq>(docSnap));
  } catch (error) {
    console.error("Error fetching category FAQs for public view:", error);
    return [];
  }
}

export async function getAllCategoryFaqsAdmin(): Promise<CategoryFaq[]> {
  try {
    const q = query(collection(db, "categoryFaqs"), orderBy("categoryId", "asc"), orderBy("displayOrder", "asc"));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(docSnap => docToPlainObject<CategoryFaq>(docSnap));
  } catch (error) {
    console.error("Error fetching all category FAQs for admin:", error);
    return [];
  }
}

export async function getCategoryFaq(id: string): Promise<CategoryFaq | null> {
  try {
    const docRef = doc(db, "categoryFaqs", id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docToPlainObject<CategoryFaq>(docSnap);
    }
    return null;
  } catch (error) {
    console.error("Error fetching category FAQ:", error);
    return null;
  }
}

export async function createCategoryFaq(data: CategoryFaqFormData): Promise<{ success: boolean; faqId?: string; error?: string }> {
  try {
    const newFaqRef = await addDoc(collection(db, "categoryFaqs"), {
      ...data,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    revalidatePath("/admin/faqs-categorias");
    // Potentially revalidate category specific pages if FAQs are shown there
    // e.g., revalidatePath(`/servicios/categoria/${data.categoryId}`); 
    return { success: true, faqId: newFaqRef.id };
  } catch (error) {
    console.error("Error creating category FAQ:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function updateCategoryFaq(id: string, data: Partial<CategoryFaqFormData>): Promise<{ success: boolean; error?: string }> {
  try {
    const faqRef = doc(db, "categoryFaqs", id);
    await updateDoc(faqRef, {
      ...data,
      updatedAt: serverTimestamp(),
    });
    revalidatePath("/admin/faqs-categorias");
    return { success: true };
  } catch (error) {
    console.error("Error updating category FAQ:", error);
    return { success: false, error: (error as Error).message };
  }
}

export async function deleteCategoryFaq(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    await deleteDoc(doc(db, "categoryFaqs", id));
    revalidatePath("/admin/faqs-categorias");
    return { success: true };
  } catch (error) {
    console.error("Error deleting category FAQ:", error);
    return { success: false, error: (error as Error).message };
  }
}


// I. Reports
export async function createReport(reporterId: string, reportData: Omit<Report, 'id' | 'reporterId' | 'status' | 'createdAt' | 'adminNotes'>) {
  try {
    const newReportRef = await addDoc(collection(db, "reports"), {
      ...reportData,
      reporterId,
      status: 'new',
      createdAt: serverTimestamp(),
    });
    // Optionally, send a notification to admin
    return { success: true, reportId: newReportRef.id };
  } catch (error) {
    console.error("Error creating report:", error);
    return { success: false, error: (error as Error).message };
  }
}

    
