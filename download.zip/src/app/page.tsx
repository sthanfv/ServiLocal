
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { Briefcase, FileText, Heart, Search, ShieldCheck, Sparkles, Users, CheckCircle, Lightbulb, UsersRound, Edit } from "lucide-react";
import Link from "next/link";
import PopularCategoriesSection from "@/components/home/PopularCategoriesSection"; // Import the new component

const FeatureCard = ({ icon, title, description, href, linkText }: { icon: React.ElementType, title: string, description: string, href?: string, linkText?: string }) => {
  const IconComponent = icon;
  return (
    <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col">
      <CardHeader className="items-center text-center">
        <div className="p-3 bg-accent/10 rounded-full mb-2">
          <IconComponent className="h-8 w-8 text-accent" />
        </div>
        <CardTitle className="text-xl">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow text-center">
        <p className="text-muted-foreground mb-4">{description}</p>
        {href && linkText && (
          <Button asChild variant="outline">
            <Link href={href}>{linkText}</Link>
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default function HomePage() {
  const { currentUser, signOut } = useAuth();

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="py-12 md:py-20 lg:py-28 bg-gradient-to-br from-primary/10 via-background to-background text-center rounded-xl shadow-inner">
        <div className="container mx-auto px-4">
          <Sparkles className="h-16 w-16 text-primary mx-auto mb-6" />
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter text-primary mb-6">
            Conectando Talento Local con Necesidades Reales
          </h1>
          <p className="text-lg md:text-xl text-foreground/80 max-w-3xl mx-auto mb-10">
            Encuentra profesionales cualificados para cualquier servicio que necesites, o regístrate para ofrecer tus habilidades a tu comunidad. ¡Fácil, rápido y seguro!
          </p>
          <div className="max-w-2xl mx-auto mb-12">
            <div className="flex gap-2 p-2 bg-card rounded-lg shadow-lg border">
              <Input
                type="search"
                placeholder="¿Qué servicio necesitas hoy? (Ej: plomero, electricista)"
                className="flex-grow text-base h-12"
              />
              <Button size="lg" className="h-12 bg-accent hover:bg-accent/90 text-accent-foreground">
                <Search className="mr-2 h-5 w-5" />
                Buscar
              </Button>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="xl" asChild className="py-4 text-lg bg-accent hover:bg-accent/90 text-accent-foreground shadow-md hover:shadow-lg transition-shadow">
              <Link href="/servicios">
                <Search className="mr-2" /> Ver Todos los Servicios
              </Link>
            </Button>
            <Button size="xl" variant="outline" asChild className="py-4 text-lg border-primary text-primary hover:bg-primary/5 shadow-md hover:shadow-lg transition-shadow">
              <Link href="/convertirse-en-proveedor">
                <Briefcase className="mr-2" /> Ofrecer Mis Servicios
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-primary">¿Cómo Funciona ServiLocal?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard
              icon={Search}
              title="1. Busca y Compara"
              description="Explora una amplia gama de servicios y proveedores. Lee perfiles, revisa calificaciones y encuentra el profesional perfecto para ti."
            />
            <FeatureCard
              icon={CheckCircle}
              title="2. Conecta y Contrata"
              description="Comunícate directamente con los proveedores, aclara dudas y acuerda los términos del servicio de forma segura y transparente."
            />
            <FeatureCard
              icon={Heart}
              title="3. Califica y Ayuda"
              description="Comparte tu experiencia calificando el servicio recibido. ¡Tu opinión ayuda a otros y mejora nuestra comunidad!"
            />
          </div>
        </div>
      </section>

      {/* Popular Categories Section - Now using the dynamic component */}
      <PopularCategoriesSection />

      {/* User specific section / Auth Call to Action */}
      <section className="py-12">
        <div className="container mx-auto px-4 text-center">
          {!currentUser ? (
            <Card className="max-w-2xl mx-auto p-8 bg-primary/5 shadow-lg">
              <CardTitle className="text-2xl font-bold mb-3 text-primary">Únete a Nuestra Comunidad</CardTitle>
              <CardDescription className="text-foreground/80 mb-6">
                Crea tu cuenta para empezar a conectar con profesionales o para ofrecer tus servicios.
              </CardDescription>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
                  <Link href="/registro">Registrarse Ahora</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/login">Ya Tengo Cuenta</Link>
                </Button>
              </div>
            </Card>
          ) : (
            <div className="max-w-2xl mx-auto">
              <p className="text-2xl font-semibold text-accent mb-3">
                ¡Hola de nuevo, {currentUser.displayName || currentUser.email}!
              </p>
              <p className="text-muted-foreground mb-6">Estás conectado y listo para explorar todo lo que ServiLocal tiene para ofrecer.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                {/* TODO: Update dashboard link based on role */}
                <Button size="lg" asChild>
                  <Link href={currentUser.displayName?.includes("Provider") ? "/dashboard/provider/servicios" : "/perfil"}>Ir a mi Panel</Link>
                </Button>
                <Button onClick={signOut} variant="outline" size="lg">
                  Cerrar Sesión
                </Button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Footer Links Quick Access (Simplified) - Full footer is in Layout */}
      <section className="py-12 border-t">
          <div className="container mx-auto px-4 text-center">
            <h3 className="text-xl font-semibold mb-6 text-primary">Enlaces de Interés</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <Link href="/terminos-y-condiciones" className="text-muted-foreground hover:text-primary"><ShieldCheck className="inline h-4 w-4 mr-1"/>Términos</Link>
              <Link href="/politica-de-privacidad" className="text-muted-foreground hover:text-primary"><FileText className="inline h-4 w-4 mr-1"/>Privacidad</Link>
              <Link href="/consejos-contratacion" className="text-muted-foreground hover:text-primary"><Lightbulb className="inline h-4 w-4 mr-1"/>Consejos</Link>
              <Link href="/apoyanos" className="text-muted-foreground hover:text-primary"><Heart className="inline h-4 w-4 mr-1"/>Apóyanos</Link>
            </div>
          </div>
      </section>
    </div>
  );
}
