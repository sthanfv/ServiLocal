
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, Gift, Handshake } from "lucide-react";
import { getActiveDonationMethods, getSiteContent } from "@/app/actions";
import type { DonationMethod, SiteContent as SiteContentType } from "@/lib/types";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import Image from "next/image";

const defaultApoyanosIntroContent = `
  <p class="mb-2">ServiLocal es un proyecto que busca facilitar la conexión entre personas que necesitan servicios y profesionales cualificados en su comunidad. Creemos en el poder de lo local y en el apoyo mutuo.</p>
  <p class="mb-2">Tu contribución, por pequeña que sea, nos ayuda a mantener la plataforma operativa, a desarrollar nuevas funcionalidades y a llegar a más personas. ¡Gracias por considerar apoyarnos!</p>
  <p class="mt-6 text-sm">Este es un texto de marcador de posición. El contenido real de esta introducción se cargará desde el sistema de gestión de contenido.</p>
`;

async function ApoyanosContent() {
  const introContentResult: SiteContentType | null = await getSiteContent("apoyanos-intro");
  const donationMethods: DonationMethod[] = await getActiveDonationMethods();

  const introTitle = introContentResult?.title || "Nuestro Proyecto y Tu Apoyo";
  const introHtml = introContentResult?.content || defaultApoyanosIntroContent;

  return (
    <div className="space-y-8">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-headline text-primary">{introTitle}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: introHtml }} />
        </CardContent>
      </Card>

      <h2 className="text-2xl font-bold tracking-tight font-headline text-center">
        Formas de Apoyar Nuestro Proyecto
      </h2>

      {donationMethods.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {donationMethods.map((method) => (
            <Card key={method.id} className="flex flex-col overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                {method.iconUrl && (
                   <div className="relative h-32 w-full mb-4">
                    <Image 
                        src={method.iconUrl} 
                        alt={method.name} 
                        layout="fill" 
                        objectFit="contain"
                        data-ai-hint="donation method icon"
                    />
                   </div>
                )}
                <CardTitle className="flex items-center gap-2">
                  {method.name === "Transferencia Bancaria" ? <DollarSign className="h-6 w-6 text-accent" /> : 
                   method.name === "Donación de Recursos" ? <Gift className="h-6 w-6 text-accent" /> : 
                   <Handshake className="h-6 w-6 text-accent" />}
                  <span>{method.name}</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <ScrollArea className="h-32 pr-3">
                 <p className="text-sm text-muted-foreground whitespace-pre-wrap">{method.instructions}</p>
                </ScrollArea>
                {method.incentiveMessage && (
                  <Alert className="mt-4 border-accent text-accent-foreground bg-accent/10">
                    <Gift className="h-4 w-4 !text-accent" />
                    <AlertTitle className="!text-accent">Incentivo</AlertTitle>
                    <AlertDescription className="!text-accent/90">
                      {method.incentiveMessage}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <p className="text-center text-muted-foreground">
          Actualmente no hay métodos de donación activos. ¡Vuelve pronto!
        </p>
      )}
    </div>
  );
}


export default function ApoyanosPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-12 text-center">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl font-headline text-primary">
          Apóyanos
        </h1>
        <p className="mt-3 text-lg text-foreground/80">
          Tu contribución nos ayuda a mantener y mejorar ServiLocal.
        </p>
      </header>
      <ApoyanosContent />
    </div>
  );
}

export const revalidate = 3600; // Revalidate a_poyanos page content every hour
