
import { getSiteContent } from "@/app/actions";
import type { SiteContent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, FileText } from "lucide-react"; // Icono genérico para documentos

export const metadata = {
  title: "Términos y Condiciones - ServiLocal",
  description: "Lee los términos y condiciones de uso de la plataforma ServiLocal.",
};

const defaultTermsContent = `
  <h2 class="text-xl font-semibold mb-3">1. Aceptación de los Términos</h2>
  <p class="mb-2">Al acceder y utilizar ServiLocal (en adelante, "la Plataforma"), usted acepta estar sujeto a estos Términos y Condiciones (en adelante, "los Términos") y a nuestra Política de Privacidad. Si no está de acuerdo con alguno de estos términos, no debe utilizar la Plataforma.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">2. Descripción del Servicio</h2>
  <p class="mb-2">ServiLocal es una plataforma que conecta a usuarios que buscan servicios (en adelante, "Clientes") con proveedores de dichos servicios (en adelante, "Proveedores"). La Plataforma facilita la búsqueda, contacto y contratación de servicios locales.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">3. Cuentas de Usuario</h2>
  <p class="mb-2">Para utilizar ciertas funciones de la Plataforma, es posible que deba registrarse y crear una cuenta. Usted es responsable de mantener la confidencialidad de su contraseña y de todas las actividades que ocurran bajo su cuenta.</p>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">4. Obligaciones de los Usuarios</h2>
  <ul class="list-disc pl-5 mb-2">
    <li>Los Clientes se comprometen a proporcionar información veraz sobre los servicios que requieren.</li>
    <li>Los Proveedores se comprometen a ofrecer servicios de calidad y a describir sus ofertas de manera precisa.</li>
    <li>Todos los usuarios se comprometen a no utilizar la Plataforma para fines ilegales o no autorizados.</li>
  </ul>
  
  <h2 class="text-xl font-semibold mb-3 mt-4">5. Limitación de Responsabilidad</h2>
  <p class="mb-2">ServiLocal actúa como un intermediario y no es responsable de la calidad, seguridad o legalidad de los servicios ofrecidos por los Proveedores, ni de la capacidad de los Clientes para pagar por dichos servicios. Cualquier disputa entre Cliente y Proveedor deberá resolverse directamente entre ellos.</p>
  
  <p class="mt-6 text-sm">Este es un texto de marcador de posición. El contenido real de los Términos y Condiciones se cargará desde el sistema de gestión de contenido.</p>
`;

async function StaticPageContent({ pageId, defaultTitle, icon: IconComponent, defaultContentHtml }: { pageId: string, defaultTitle: string, icon: React.ElementType, defaultContentHtml?: string }) {
  const content: SiteContent | null = await getSiteContent(pageId);
  let displayContent: string;
  let displayTitle: string;
  let lastUpdated: string | null = null;

  if (content) {
    displayTitle = content.title || defaultTitle;
    displayContent = content.content;
    lastUpdated = content.lastUpdatedAt ? new Date(content.lastUpdatedAt as any).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric'}) : 'N/A';
  } else if (defaultContentHtml) {
    displayTitle = defaultTitle;
    displayContent = defaultContentHtml;
  } else {
    return (
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
            <IconComponent className="h-8 w-8 text-primary" />
            {defaultTitle}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center text-center py-12">
            <AlertCircle className="h-12 w-12 text-destructive mb-4" />
            <h1 className="text-2xl font-bold mb-2">Contenido no encontrado</h1>
            <p className="text-muted-foreground">
              No pudimos cargar el contenido de esta página. Por favor, inténtalo más tarde.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-3xl font-headline text-primary flex items-center gap-2">
          <IconComponent className="h-8 w-8 text-primary" /> 
          {displayTitle}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: displayContent }} />
        {lastUpdated && (
         <p className="mt-6 text-sm text-muted-foreground">
          Última actualización: {lastUpdated}
        </p>
        )}
      </CardContent>
    </Card>
  );
}


export default function TerminosPage() {
  return (
    <div className="container mx-auto px-4 py-8">
       <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl font-headline text-primary">
          Términos y Condiciones
        </h1>
      </header>
      <StaticPageContent 
        pageId="terminos-y-condiciones" 
        defaultTitle="Términos y Condiciones"
        icon={FileText}
        defaultContentHtml={defaultTermsContent} 
      />
    </div>
  );
}

export const revalidate = 86400; // Revalidate static pages daily
