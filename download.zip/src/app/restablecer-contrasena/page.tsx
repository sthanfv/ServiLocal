"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useForm, type SubmitHandler } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { PasswordResetSchema, type PasswordResetFormData } from "@/lib/schemas";
import AuthFormWrapper from "@/components/auth/AuthFormWrapper";
import { useAuth } from "@/contexts/AuthContext";
import type { AuthError } from "firebase/auth";
import { useState } from "react";

export default function PasswordResetPage() {
  const { toast } = useToast();
  const { sendPasswordReset } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const form = useForm<PasswordResetFormData>({
    resolver: zodResolver(PasswordResetSchema),
    defaultValues: {
      email: "",
    },
  });

  const onSubmit: SubmitHandler<PasswordResetFormData> = async (data) => {
    setIsLoading(true);
    setEmailSent(false);
    try {
      const result = await sendPasswordReset(data.email);
       if (result && 'code' in result) { // AuthError
        const error = result as AuthError;
        let friendlyMessage = "Error al enviar el correo. Inténtalo de nuevo.";
        if (error.code === "auth/user-not-found") {
          friendlyMessage = "No se encontró un usuario con este correo electrónico.";
        }
         toast({
          title: "Error",
          description: friendlyMessage,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Correo Enviado",
          description: "Si tu correo está registrado, recibirás un enlace para restablecer tu contraseña.",
        });
        setEmailSent(true);
      }
    } catch (error) {
       toast({
        title: "Error",
        description: "Ocurrió un error inesperado. Por favor, inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthFormWrapper
      title="Restablecer Contraseña"
      description={!emailSent ? "Ingresa tu correo electrónico para recibir un enlace de restablecimiento." : "Revisa tu bandeja de entrada (y spam) para el enlace de restablecimiento."}
      footerContent={
        <Button variant="link" asChild className="px-0">
          <Link href="/login">Volver a Iniciar Sesión</Link>
        </Button>
      }
    >
      {!emailSent ? (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Correo Electrónico</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="tu@correo.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "Enviando..." : "Enviar Enlace de Restablecimiento"}
            </Button>
          </form>
        </Form>
      ) : (
        <p className="text-center text-green-600">
          Se ha enviado un correo electrónico con instrucciones a la dirección proporcionada si está registrada.
        </p>
      )}
    </AuthFormWrapper>
  );
}
