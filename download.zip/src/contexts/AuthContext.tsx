"use client";

import type { User as FirebaseUser, AuthError } from 'firebase/auth';
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { auth }
  from '@/lib/firebase';
import { 
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail
} from 'firebase/auth';
import type { User } from '@/lib/types'; // Assuming User type might be extended beyond FirebaseUser

interface AuthContextType {
  currentUser: FirebaseUser | null;
  loading: boolean;
  userProfile: User | null; // Potentially richer user profile from Firestore
  signUp: (email: string, pass: string) => Promise<FirebaseUser | AuthError>;
  signIn: (email: string, pass: string) => Promise<FirebaseUser | AuthError>;
  signOut: () => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void | AuthError>;
  // Function to fetch/set full user profile from Firestore
  fetchUserProfile: (uid: string) => Promise<void>; 
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        // await fetchUserProfile(user.uid); // Example: fetch full profile on auth change
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const signUp = async (email: string, pass: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
      // Trigger for creating user document in Firestore should be handled by a Cloud Function (onUserCreate)
      return userCredential.user;
    } catch (error) {
      return error as AuthError;
    }
  };

  const signIn = async (email: string, pass: string) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, pass);
      return userCredential.user;
    } catch (error) {
      return error as AuthError;
    }
  };

  const signOut = async () => {
    try {
      await firebaseSignOut(auth);
    } catch (error) {
      console.error("Error signing out: ", error);
    }
  };
  
  const sendPasswordReset = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error) {
      return error as AuthError;
    }
  };

  // Placeholder for fetching full user profile from Firestore
  // This would typically involve a server action or a direct client-side read if rules allow
  const fetchUserProfile = async (uid: string) => {
    // Example: const profile = await getUserProfileServerAction(uid); setUserProfile(profile);
    // For now, this is a placeholder. Actual implementation will depend on how user data is fetched.
  };

  const value = {
    currentUser,
    loading,
    userProfile,
    signUp,
    signIn,
    signOut,
    sendPasswordReset,
    fetchUserProfile,
  };

  return <AuthContext.Provider value={value}>{!loading && children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
