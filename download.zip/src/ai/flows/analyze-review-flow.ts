
'use server';
/**
 * @fileOverview Un agente de IA para analizar y marcar reseñas de usuarios.
 *
 * - analyzeReview - Una función que maneja el proceso de análisis de reseñas.
 */

import { ai } from '@/ai/genkit';
// Import Zod schemas from the central schemas file
import { AnalyzeReviewInputSchema, AnalyzeReviewOutputSchema } from '@/lib/schemas';
// Import TypeScript types from the central types file
import type { AnalyzeReviewInput, AnalyzeReviewOutput } from '@/lib/types';


// Wrapper function to be called from server actions or other server-side code
export async function analyzeReview(input: AnalyzeReviewInput): Promise<AnalyzeReviewOutput> {
  return analyzeReviewFlow(input);
}

const analyzeReviewPrompt = ai.definePrompt({
  name: 'analyzeReviewPrompt',
  input: { schema: AnalyzeReviewInputSchema },
  output: { schema: AnalyzeReviewOutputSchema },
  prompt: `Eres un sistema experto en moderación de contenido para "ServiLocal", una plataforma que conecta clientes con proveedores de servicios locales.
Tu tarea es analizar las reseñas enviadas por los usuarios sobre los servicios recibidos y marcar aquellas que violen nuestras políticas de contenido, parezcan problemáticas o no sean útiles.

Políticas de Contenido y Directrices para Marcar:
1.  **SPAM_PROMOTIONAL**: No se permite spam, publicidad no solicitada, o contenido puramente promocional no relacionado con una experiencia genuina.
2.  **IRRELEVANT**: Las reseñas deben ser relevantes al servicio recibido y a la categoría del servicio (si se proporciona: {{{serviceCategory}}}). Contenido fuera de tema o que hable de otros productos/servicios debe ser marcado.
3.  **PROFANE_OFFENSIVE**: No se permite lenguaje profano, vulgar u ofensivo.
4.  **HATE_SPEECH_DISCRIMINATORY**: No se permite discurso de odio, comentarios discriminatorios basados en raza, etnia, religión, género, orientación sexual, etc.
5.  **FAKE_ENGAGEMENT_LOW_DETAIL**: Reseñas que parecen ser falsas, manipuladas o destinadas a inflar/desinflar artificialmente la reputación. Presta especial atención a:
    *   Reseñas extremadamente positivas (ej. 5 estrellas) o negativas (ej. 1 estrella) con texto muy genérico, corto y sin detalles específicos (ej: "Excelente servicio", "Muy malo").
    *   Múltiples reseñas muy similares de diferentes usuarios (esto no lo puedes detectar con una sola reseña, pero tenlo en cuenta si el patrón es muy obvio en el texto).
6.  **NON_CONSTRUCTIVE**: Reseñas que son excesivamente vagas, no aportan información útil para otros usuarios o no describen una experiencia real. (Ej: "No me gustó.", "Ok.").
7.  **SAFETY_CONCERN**: Si la reseña menciona un problema grave de seguridad relacionado con el servicio o el proveedor que requiera atención urgente.
8.  **OTHER**: Para cualquier otro problema que no encaje en las categorías anteriores pero que consideres que viola el espíritu de una comunidad respetuosa y útil.

Si la reseña cumple con las políticas y es constructiva, establece 'isSuspicious' en 'false' y 'flagCategory' en 'NONE'.

Analiza la siguiente reseña:
Texto de la Reseña: "{{{reviewText}}}"
{{#if reviewRating}}Calificación Otorgada: {{{reviewRating}}} de 5 estrellas.{{/if}}
{{#if serviceCategory}}Categoría del Servicio: {{{serviceCategory}}}{{/if}}

Considera tanto el texto de la reseña como la calificación (si se proporciona) y la categoría del servicio (si se proporciona) en tu análisis.
Una reseña de 1 o 5 estrellas con texto muy genérico es más sospechosa que una detallada.
Si la reseña es marcada (isSuspicious: true), proporciona una 'flagCategory' adecuada y una 'reason' concisa explicando tu decisión.
Si la reseña es marcada, también puedes proporcionar un 'confidenceScore' entre 0 (baja confianza) y 1 (alta confianza) sobre tu decisión. Si no es sospechosa, no es necesario el confidenceScore.

Devuelve tu análisis ÚNICAMENTE en el formato JSON especificado por el esquema de salida.
`,
  config: {
    safetySettings: [
      { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' }, 
    ],
  },
});

const analyzeReviewFlow = ai.defineFlow(
  {
    name: 'analyzeReviewFlow',
    inputSchema: AnalyzeReviewInputSchema,
    outputSchema: AnalyzeReviewOutputSchema,
  },
  async (input: AnalyzeReviewInput): Promise<AnalyzeReviewOutput> => {
    const { output } = await analyzeReviewPrompt(input);

    if (!output) {
      console.error('AnalyzeReviewFlow: El modelo no generó una salida válida o fue bloqueada.');
      return {
        isSuspicious: true, 
        flagCategory: "OTHER",
        reason: "El análisis automático de la reseña falló o fue bloqueado. Requiere revisión manual.",
        // confidenceScore is optional, so not providing it here is fine.
      };
    }
    return output;
  }
);
