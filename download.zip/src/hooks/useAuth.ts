"use client";

import { useContext } from 'react';
// This change implies AuthContext.tsx needs to export AuthContext directly or adjust useAuth hook.
// Assuming AuthContext is exported from '@/contexts/AuthContext'
// If AuthContextType is also in AuthContext.tsx, ensure it's exported or redefine here.
import { AuthContext } from '@/contexts/AuthContext'; 
// Ensure AuthContextType is available. It might be better to define it within AuthContext.tsx and export it.
// For simplicity, if AuthContextType is complex and defined in AuthContext.tsx,
// this hook would directly use the context without redefining AuthContextType.

// Re-defining AuthContextType for clarity if not exported, or ensuring it is exported from AuthContext.tsx
// For this example, let's assume AuthContextType is correctly handled by being exported or this hook
// just infers its type from AuthContext.

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
