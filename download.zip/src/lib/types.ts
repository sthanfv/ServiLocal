
import type { Timestamp } from 'firebase/firestore';
import type { z } from 'zod'; // Import z for inference
import type { AnalyzeReviewInputSchema, AnalyzeReviewOutputSchema } from './schemas'; // Import Zod schemas

export interface User {
  id: string; // UID from Firebase Auth
  email: string | null;
  displayName: string | null;
  role: 'client' | 'provider' | 'admin';
  createdAt: Timestamp;
  updatedAt: Timestamp;
  isVerified: boolean;
  isDonor: boolean;
  providerProfile?: ProviderProfile;
}

export interface ProviderProfile {
  businessName?: string;
  providerDescription?: string;
  serviceCategoriesText?: string; // Textual description, e.g., "Fontanería, Electricidad"
  serviceLocations?: string; // Textual description, e.g., "Ciudad XYZ, Barrio ABC"
  contactPhone?: string;
  websiteUrl?: string;
  portfolioImages?: string[]; // URLs to images in Cloud Storage
  averageRating?: number; // Calculated, 0-5
  reviewCount?: number; // Calculated
}

export interface ServiceCategory {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  iconUrl?: string; // Opcional, podríamos implementarlo más adelante
  slug: string;
  createdAt?: Timestamp; // Añadido para seguimiento
  updatedAt?: Timestamp; // Añadido para seguimiento
}

export interface Service {
  id: string;
  providerId: string; // UID of the provider user
  providerDisplayName: string; // Denormalized
  categoryId: string; // ID of ServiceCategory document
  categoryName: string; // Denormalized
  title: string;
  description: string; // Long text
  priceRange: string; // e.g., "50€ - 100€", "A convenir"
  serviceImages: string[]; // URLs to images in Cloud Storage, max 3
  status: 'pending_approval' | 'active' | 'rejected' | 'archived';
  locationText: string; // Textual description of service location or area covered
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface Review {
  id: string;
  providerId: string;
  clientId: string;
  clientDisplayName: string; // Denormalized
  serviceId?: string; // Optional, if review is for a specific service
  rating: number; // 1-5
  comment: string; // Long text
  createdAt: Timestamp;
  aiAnalysis?: AnalyzeReviewOutput; // Stores the AI analysis result object
  aiAnalyzedAt?: Timestamp;      // Timestamp of when the analysis was performed
}

export interface Chat {
  id: string;
  participantIds: string[];
  lastMessageText?: string;
  lastMessageTimestamp?: Timestamp;
  lastMessageSenderId?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: Timestamp;
  isRead?: boolean; // Or Map for group chats
}

export interface PublicServiceRequest {
  id: string;
  clientId: string;
  clientDisplayName: string; // Denormalized
  title: string;
  description: string;
  categoryId: string;
  categoryName: string; // Denormalized
  locationText: string;
  status: 'pending_approval' | 'active' | 'rejected' | 'completed';
  createdAt: Timestamp;
}

export interface DonationMethod {
  id: string;
  name: string;
  instructions: string; // Long text
  incentiveMessage: string;
  iconUrl?: string;
  isActive: boolean;
  displayOrder: number;
}

export interface SiteContent {
  id: string; // Slug, e.g., "terminos-y-condiciones"
  title: string;
  content: string; // Markdown or HTML
  lastUpdatedAt: Timestamp;
}

export interface CategoryFaq {
  id: string;
  categoryId: string;
  question: string;
  answer: string; // Long text
  isActive: boolean;
  displayOrder: number;
}

export interface Report {
  id: string;
  reporterId: string;
  reportedItemType: 'service' | 'user' | 'review' | 'publicServiceRequest';
  reportedItemId: string;
  reason: string; // e.g., "Contenido inapropiado", "Spam"
  comment?: string; // Optional additional details
  status: 'new' | 'under_review' | 'resolved_action_taken' | 'resolved_dismissed';
  adminNotes?: string;
  createdAt: Timestamp;
}

// Types for AnalyzeReviewFlow (AI)
export type AnalyzeReviewInput = z.infer<typeof AnalyzeReviewInputSchema>;
export type AnalyzeReviewOutput = z.infer<typeof AnalyzeReviewOutputSchema>;
