import { z } from 'zod';

export const LoginSchema = z.object({
  email: z.string().email({ message: "Por favor ingresa un correo electrónico válido." }),
  password: z.string().min(1, { message: "Por favor ingresa tu contraseña." }),
});
export type LoginFormData = z.infer<typeof LoginSchema>;

export const RegisterSchema = z.object({
  email: z.string().email({ message: "Por favor ingresa un correo electrónico válido." }),
  password: z.string().min(6, { message: "La contraseña debe tener al menos 6 caracteres." }),
  confirmPassword: z.string(),
  // role: z.enum(['client', 'provider']).default('client'), // Role selection can be a separate step or default
}).refine((data) => data.password === data.confirmPassword, {
  message: "Las contraseñas no coinciden.",
  path: ["confirmPassword"],
});
export type RegisterFormData = z.infer<typeof RegisterSchema>;

export const PasswordResetSchema = z.object({
  email: z.string().email({ message: "Por favor ingresa un correo electrónico válido." }),
});
export type PasswordResetFormData = z.infer<typeof PasswordResetSchema>;

// Esquema para el formulario de creación/edición de categorías de servicio
export const ServiceCategorySchema = z.object({
  name: z.string().min(3, { message: "El nombre debe tener al menos 3 caracteres." }).max(100, { message: "El nombre no puede exceder los 100 caracteres." }),
  description: z.string().min(10, { message: "La descripción debe tener al menos 10 caracteres." }).max(500, { message: "La descripción no puede exceder los 500 caracteres." }),
  slug: z.string()
    .min(3, { message: "El slug debe tener al menos 3 caracteres." })
    .max(100, { message: "El slug no puede exceder los 100 caracteres."})
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, { message: "El slug solo puede contener letras minúsculas, números y guiones, y no puede empezar ni terminar con guion." })
    .refine(value => !value.startsWith('-') && !value.endsWith('-'), { message: "El slug no puede empezar ni terminar con guion." }),
  isActive: z.boolean().default(true),
  iconUrl: z.string().url({ message: "Por favor ingresa una URL válida para el icono." }).optional().or(z.literal('')), // Opcional y puede ser una cadena vacía
});
export type ServiceCategoryFormData = z.infer<typeof ServiceCategorySchema>;

// Esquema para el formulario de edición de contenido estático
export const SiteContentSchema = z.object({
  title: z.string().min(3, { message: "El título debe tener al menos 3 caracteres." }).max(200, { message: "El título no puede exceder los 200 caracteres." }),
  content: z.string().min(10, { message: "El contenido debe tener al menos 10 caracteres." }), // Contenido HTML
});
export type SiteContentFormData = z.infer<typeof SiteContentSchema>;

// Esquema para el formulario de creación/edición de Métodos de Donación
export const DonationMethodSchema = z.object({
  name: z.string().min(3, { message: "El nombre debe tener al menos 3 caracteres." }).max(100),
  instructions: z.string().min(10, { message: "Las instrucciones deben tener al menos 10 caracteres." }),
  incentiveMessage: z.string().max(200).optional().or(z.literal('')),
  iconUrl: z.string().url({ message: "URL de icono no válida."}).optional().or(z.literal('')),
  isActive: z.boolean().default(true),
  displayOrder: z.coerce.number().int().min(0, { message: "El orden debe ser un número positivo."}).default(0),
});
export type DonationMethodFormData = z.infer<typeof DonationMethodSchema>;

// Esquema para el formulario de creación/edición de FAQs por Categoría
export const CategoryFaqSchema = z.object({
  categoryId: z.string().min(1, { message: "Debes seleccionar una categoría." }),
  question: z.string().min(5, { message: "La pregunta debe tener al menos 5 caracteres." }).max(250, { message: "La pregunta no puede exceder los 250 caracteres."}),
  answer: z.string().min(10, { message: "La respuesta debe tener al menos 10 caracteres." }).max(2000, { message: "La respuesta no puede exceder los 2000 caracteres."}),
  isActive: z.boolean().default(true),
  displayOrder: z.coerce.number().int().min(0, { message: "El orden debe ser un número positivo."}).default(0),
});
export type CategoryFaqFormData = z.infer<typeof CategoryFaqSchema>;

// Esquemas para AnalyzeReviewFlow (AI)
export const AnalyzeReviewInputSchema = z.object({
  reviewText: z.string().min(1, { message: "El texto de la reseña no puede estar vacío." }).describe('El contenido textual de la reseña del usuario.'),
  reviewRating: z.number().min(1).max(5).optional().describe('La calificación en estrellas (1-5) otorgada por el usuario, si está disponible.'),
  serviceCategory: z.string().optional().describe('La categoría del servicio reseñado, si está disponible, para ayudar a determinar la relevancia.'),
});

export const AnalyzeReviewOutputSchema = z.object({
  isSuspicious: z.boolean().describe('Indica si la reseña se considera sospechosa o problemática.'),
  flagCategory: z.enum([
    "NONE", 
    "SPAM_PROMOTIONAL", 
    "IRRELEVANT", 
    "PROFANE_OFFENSIVE", 
    "HATE_SPEECH_DISCRIMINATORY", 
    "FAKE_ENGAGEMENT_LOW_DETAIL", 
    "NON_CONSTRUCTIVE", 
    "SAFETY_CONCERN", 
    "OTHER", 
  ]).describe('Categoría de la marca si la reseña es sospechosa. "NONE" si no es sospechosa.'),
  reason: z.string().optional().describe('Una breve explicación de por qué la reseña fue marcada, si aplica.'),
  confidenceScore: z.number().min(0).max(1).optional().describe('Puntuación de confianza (0-1) en la decisión de marcado, si aplica.'),
});
