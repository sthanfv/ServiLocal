
import { initializeApp, getApps, getApp, type FirebaseOptions } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// --- User-provided Firebase configuration (TEMPORARILY HARDCODED FOR TESTING) ---
// This is TEMPORARY. The goal is for Firebase Studio to provide these via process.env.
const firebaseConfigHardcoded: FirebaseOptions = {
  apiKey: "AIzaSyANrWDKI9X06DSK9T8xYshcsARIUVj_CLk",
  authDomain: "servicio-local-wl850.firebaseapp.com",
  projectId: "servicio-local-wl850",
  storageBucket: "servicio-local-wl850.firebasestorage.app", // Corrected based on user's direct input
  messagingSenderId: "481997518930",
  appId: "1:481997518930:web:bb82d0e0dcd7637973878b"
};

// --- Configuration using environment variables (IDEAL TARGET STATE - CURRENTLY NOT WORKING IN STUDIO) ---
/*
const firebaseConfigEnv: FirebaseOptions = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};
*/

// Initialize Firebase
// We will use firebaseConfigHardcoded for now.
const app = !getApps().length ? initializeApp(firebaseConfigHardcoded) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export { app, auth, db, storage };
