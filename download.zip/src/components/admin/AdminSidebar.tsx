
"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Sidebar,
  SidebarHeader as UiSidebarHeader, // Aliased to avoid confusion if SheetHeader was also used here
  SidebarTrigger, 
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  useSidebar, 
} from "@/components/ui/sidebar";
import Logo from "@/components/Logo";
import { 
  Home, 
  Users, 
  Briefcase, 
  LayoutList, 
  FileText, 
  MessageSquareWarning, 
  Gift, 
  HelpCircle, 
  ShieldAlert, 
  LogOut,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"; 
import { cn } from "@/lib/utils";

const adminNavItems = [
  { title: "Panel Principal", href: "/admin", icon: Home },
  { title: "Usuarios", href: "/admin/usuarios", icon: Users },
  { title: "Servicios", href: "/admin/servicios", icon: Briefcase },
  { title: "Categorías", href: "/admin/categorias", icon: LayoutList },
  { title: "Contenido Estático", href: "/admin/contenido-estatico", icon: FileText },
  { title: "Solicitudes Públicas", href: "/admin/solicitudes-publicas", icon: MessageSquareWarning },
  { title: "Métodos Donación", href: "/admin/metodos-donacion", icon: Gift },
  { title: "FAQs por Categoría", href: "/admin/faqs-categorias", icon: HelpCircle },
  { title: "Reportes", href: "/admin/reportes", icon: ShieldAlert },
];

// Contenido del Sidebar (común para móvil y escritorio)
function SidebarNavigationContent({ isMobileSheetContext = false }: { isMobileSheetContext?: boolean }) {
  const pathname = usePathname();
  const { signOut } = useAuth();
  const router = useRouter();
  const { setOpenMobile } = useSidebar(); 

  const handleSignOut = async () => {
    await signOut();
    if (isMobileSheetContext) setOpenMobile(false);
    router.push('/login');
  };

  return (
    <>
      {/* Only render the UiSidebarHeader for desktop context */}
      {!isMobileSheetContext && (
        <UiSidebarHeader className="p-4 flex items-center justify-between h-16 border-b border-sidebar-border">
          <div className={cn("group-data-[collapsible=icon]:hidden")}>
            <Logo />
          </div>
          <SidebarTrigger className="hidden md:flex" />
        </UiSidebarHeader>
      )}
      <SidebarContent className={cn("p-2 flex-grow overflow-y-auto")}>
        <SidebarMenu>
          {adminNavItems.map((item) => (
            <SidebarMenuItem key={item.href}>
              <SidebarMenuButton
                asChild
                isActive={pathname === item.href || (item.href !== "/admin" && pathname.startsWith(item.href))}
                onClick={isMobileSheetContext ? () => setOpenMobile(false) : undefined}
                tooltip={!isMobileSheetContext ? { children: item.title, side: "right", className: "bg-primary text-primary-foreground" } : undefined}
              >
                <Link href={item.href}>
                  <item.icon className="h-5 w-5" />
                  <span>{item.title}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-2 border-t border-sidebar-border">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={handleSignOut}
              className="w-full"
              tooltip={!isMobileSheetContext ? { children: "Cerrar Sesión", side: "right", className: "bg-primary text-primary-foreground" } : undefined}
            >
              <LogOut className="h-5 w-5" />
              <span>Cerrar Sesión</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </>
  );
}


export default function AdminSidebar() {
  const { isMobile, openMobile, setOpenMobile } = useSidebar();

  if (isMobile) {
    return (
      <Sheet open={openMobile} onOpenChange={setOpenMobile}>
        <SheetContent
          side="left"
          className="w-[280px] bg-sidebar p-0 text-sidebar-foreground flex flex-col" 
          data-testid="mobile-sidebar-content"
        >
          {/* Add SheetHeader and SheetTitle here for accessibility for the mobile sheet */}
          <SheetHeader className="p-4 flex items-center justify-between h-16 border-b border-sidebar-border">
            <SheetTitle>
              <Logo />
            </SheetTitle>
            {/* SheetClose is automatically added by SheetContent's default structure */}
          </SheetHeader>
          <SidebarNavigationContent isMobileSheetContext={true} />
        </SheetContent>
      </Sheet>
    );
  }

  // Desktop sidebar
  return (
    <Sidebar collapsible="icon" className="border-r bg-sidebar hidden md:flex"> {/* This is the ui/sidebar <Sidebar> component */}
      <SidebarNavigationContent isMobileSheetContext={false} />
    </Sidebar>
  );
}
