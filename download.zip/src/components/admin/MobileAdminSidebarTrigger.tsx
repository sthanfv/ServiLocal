
'use client';

import { useSidebar, SidebarTrigger as UiSidebarTrigger } from "@/components/ui/sidebar";

// Component para el disparador del menú móvil
export default function MobileAdminSidebarTrigger() {
  const { isMobile, openMobile } = useSidebar(); // Get openMobile state

  // Do not render the trigger if it's not mobile view OR if the mobile sidebar is already open
  if (!isMobile || openMobile) {
    return null;
  }

  // Movido a la esquina superior izquierda, pero más abajo para no tapar el header principal.
  // El header principal tiene h-16 (64px). top-20 (80px) debería estar justo debajo.
  return (
    <UiSidebarTrigger className="fixed top-20 left-4 z-[60] md:hidden bg-primary text-primary-foreground hover:bg-primary/90 h-10 w-10 shadow-lg rounded-lg" />
  );
}
