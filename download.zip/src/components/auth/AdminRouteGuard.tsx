
"use client";

import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ShieldAlert } from "lucide-react";

export default function AdminRouteGuard({ children }: { children: React.ReactNode }) {
  const { currentUser, loading: authLoading } = useAuth();
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [checkingStatus, setCheckingStatus] = useState(true);

  useEffect(() => {
    if (authLoading) {
      return; 
    }

    if (!currentUser) {
      router.push("/login?redirect=/admin"); 
      setCheckingStatus(false);
      return;
    }

    // TODO: REVERT THIS TEMPORARY ADMIN ACCESS CHECK.
    // This is a temporary check for development purposes ONLY.
    // Replace with proper custom claims check before production.
    if (currentUser.email === "admin@servilocal.com") {
      setIsAdmin(true);
      setCheckingStatus(false);
      return;
    }
    // END OF TEMPORARY CHECK

    currentUser.getIdTokenResult(true) 
      .then((idTokenResult) => {
        if (idTokenResult.claims.admin === true) {
          setIsAdmin(true);
        } else {
          setIsAdmin(false);
        }
      })
      .catch((error) => {
        console.error("Error al obtener el token ID y claims:", error);
        setIsAdmin(false); // Asumir no admin si hay error
      })
      .finally(() => {
        setCheckingStatus(false);
      });

  }, [currentUser, authLoading, router]);

  if (authLoading || checkingStatus) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <Skeleton className="h-8 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-6 w-3/4 mt-2" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isAdmin === false) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center bg-background">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-destructive flex items-center justify-center gap-2">
              <ShieldAlert className="h-8 w-8" />
              Acceso Denegado
            </CardTitle>
            <CardDescription>
              No tienes los permisos necesarios para acceder a esta sección.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-6 text-muted-foreground">
              Si crees que esto es un error, por favor contacta al administrador del sitio.
            </p>
            <Button asChild>
              <Link href="/">Volver a la Página Principal</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isAdmin === true) {
    return <>{children}</>;
  }

  // Fallback en caso de que isAdmin siga siendo null, aunque no debería ocurrir con la lógica actual
  return ( 
     <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center">
        <p>Verificando acceso...</p>
     </div>
  );
}
