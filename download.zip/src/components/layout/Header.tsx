
"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { siteConfig, type NavItem } from '@/config/site';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Search, MessageSquare, Bell, LogOut, UserCircle, LayoutDashboard, ShieldCheck } from 'lucide-react';

export default function Header() {
  const pathname = usePathname();
  const { currentUser, signOut, loading } = useAuth();

  const UserNav = () => {
    if (loading) {
      return <div className="w-8 h-8 bg-muted rounded-full animate-pulse" />;
    }
    if (currentUser) {
      const isAdmin = currentUser.email === "admin@servilocal.com";
      // TODO: Implement proper role check for provider (e.g., custom claims or userProfile.role)
      // For now, we rely on userProfile which might take a moment to load.
      // A more robust check might involve custom claims immediately available.
      const isProvider = currentUser.email?.includes("provider"); // Temporary placeholder

      let dashboardLink = "/perfil"; 
      let dashboardLabel = "Mi Panel";

      if (isAdmin) {
        dashboardLink = "/admin";
        dashboardLabel = "Panel de Admin";
      } else if (isProvider) {
        // This will be refined once provider roles are properly set up via userProfile
        dashboardLink = "/dashboard/provider/servicios"; 
        dashboardLabel = "Panel de Proveedor";
      }


      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 w-8 rounded-full">
              <Avatar className="h-8 w-8">
                <AvatarImage src={currentUser.photoURL || undefined} alt={currentUser.displayName || currentUser.email || "Usuario"} />
                <AvatarFallback>{currentUser.email?.[0]?.toUpperCase() || 'U'}</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-64 md:w-56" align="end" forceMount> {/* Aumentado ancho para móvil, mantenido para desktop */}
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">
                  {currentUser.displayName || currentUser.email}
                </p>
                <p className="text-xs leading-none text-muted-foreground">
                  {currentUser.email}
                </p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/perfil">
                <UserCircle className="mr-2 h-4 w-4" />
                <span>Perfil</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href={dashboardLink}>
                {isAdmin ? <ShieldCheck className="mr-2 h-4 w-4" /> : <LayoutDashboard className="mr-2 h-4 w-4" />}
                <span>{dashboardLabel}</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={signOut}>
              <LogOut className="mr-2 h-4 w-4" />
              Cerrar Sesión
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    }
    return (
      <div className="space-x-2">
        <Button asChild variant="ghost">
          <Link href="/login">Iniciar Sesión</Link>
        </Button>
        <Button asChild>
          <Link href="/registro">Registrarse</Link>
        </Button>
      </div>
    );
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <TooltipProvider>
        <div className="container px-12 flex h-16 max-w-screen-2xl items-center justify-between"> {/* Changed px-8 to px-12 */}
          <Logo />
          <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
            {siteConfig.mainNav.map((item: NavItem) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "transition-colors hover:text-foreground/80",
                  pathname === item.href ? "text-foreground" : "text-foreground/60"
                )}
              >
                {item.title}
              </Link>
            ))}
          </nav>
          <div className="flex items-center space-x-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Buscar">
                  <Search className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Buscar servicios</p>
              </TooltipContent>
            </Tooltip>
            {currentUser && (
              <>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" aria-label="Mensajes">
                      <MessageSquare className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Mensajes (Próximamente)</p>
                  </TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" aria-label="Notificaciones">
                      <Bell className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Notificaciones (Próximamente)</p>
                  </TooltipContent>
                </Tooltip>
              </>
            )}
            <UserNav />
          </div>
        </div>
      </TooltipProvider>
    </header>
  );
}
