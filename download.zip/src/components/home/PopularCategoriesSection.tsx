
"use client";

import { getActiveServiceCategories } from "@/app/actions";
import type { ServiceCategory } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Loader2, AlertTriangle, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

// This sub-component will handle the rendering of actual content once data is loaded
function PopularCategoriesContentDisplay({ categories }: { categories: ServiceCategory[] }) {
  if (categories.length === 0) {
    return (
      <div className="text-center text-muted-foreground py-8">
        <Info className="mx-auto h-12 w-12 mb-4 text-muted-foreground/70" />
        <p className="text-xl font-semibold">No hay categorías populares</p>
        <p>Aún no se han configurado categorías populares para mostrar.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {categories.map((category) => (
        <Link href={`/servicios?categoriaId=${category.id}`} key={category.id} className="group block h-full">
          <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col h-full overflow-hidden">
            <CardHeader className="p-0 relative aspect-video">
              <Image
                src={category.iconUrl || `https://placehold.co/600x400.png`}
                alt={category.name}
                fill
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                style={{ objectFit: "cover" }}
                className="transition-transform duration-300 group-hover:scale-110"
                data-ai-hint="category image"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
               <CardTitle className="absolute bottom-0 left-0 p-4 text-lg font-semibold text-primary-foreground group-hover:text-accent transition-colors">
                {category.name}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 flex-grow flex flex-col justify-between">
              <p className="text-sm text-muted-foreground line-clamp-2 mb-3 h-10">
                {category.description || `Explora servicios en la categoría ${category.name}.`}
              </p>
               <Button variant="outline" size="sm" className="w-full group-hover:bg-accent group-hover:text-accent-foreground transition-colors mt-auto">
                Ver Servicios <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
}

export default function PopularCategoriesSection() {
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        setError(null);
        const fetchedCategories = await getActiveServiceCategories();
        setCategories(fetchedCategories.slice(0, 4)); // Show up to 4
      } catch (err) {
        console.error("Error fetching popular categories:", err);
        setError("No se pudieron cargar las categorías populares.");
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, []);

  return (
    <section className="py-12 md:py-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-10">
          <h2 className="text-3xl font-bold text-primary text-center sm:text-left mb-4 sm:mb-0">
            Categorías Populares
          </h2>
          <Button variant="ghost" asChild>
            <Link href="/servicios" className="text-primary hover:text-primary/80">
              Ver Todas las Categorías <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
        {isLoading && (
          <div className="flex justify-center items-center py-10 min-h-[200px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-2">Cargando categorías...</p>
          </div>
        )}
        {error && (
          <div className="text-center py-10 text-destructive min-h-[200px]">
            <AlertTriangle className="mx-auto h-12 w-12 mb-4" />
            <p className="text-xl font-semibold">{error}</p>
          </div>
        )}
        {!isLoading && !error && <PopularCategoriesContentDisplay categories={categories} />}
      </div>
    </section>
  );
}
