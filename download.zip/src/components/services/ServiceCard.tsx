
import type { Service } from "@/lib/types";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Tag, UserCircle } from "lucide-react";

interface ServiceCardProps {
  service: Service;
}

export default function ServiceCard({ service }: ServiceCardProps) {
  const firstImage = service.serviceImages?.[0] || `https://placehold.co/600x400.png`;

  return (
    <Card className="flex flex-col overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
      <CardHeader className="p-0">
        <div className="relative w-full aspect-video">
          <Image
            src={firstImage}
            alt={service.title}
            layout="fill"
            objectFit="cover"
            className="transition-transform duration-300 group-hover:scale-110"
            data-ai-hint="service related image"
          />
        </div>
      </CardHeader>
      <CardContent className="p-4 flex-grow space-y-3">
        <Badge variant="secondary" className="mb-2">{service.categoryName}</Badge>
        <CardTitle className="text-xl font-semibold line-clamp-2">
          <Link href={`/servicios/${service.id}`} className="hover:text-primary transition-colors">
            {service.title}
          </Link>
        </CardTitle>
        <CardDescription className="line-clamp-3 text-sm">
          {service.description}
        </CardDescription>
        
        <div className="space-y-2 text-xs text-muted-foreground pt-2">
          <div className="flex items-center gap-1.5">
            <UserCircle className="h-3.5 w-3.5" />
            <span>{service.providerDisplayName}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5" />
            <span>{service.locationText}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Tag className="h-3.5 w-3.5" />
            <span>{service.priceRange}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 border-t">
        <Button asChild className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
          <Link href={`/servicios/${service.id}`}>Ver Detalles</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
