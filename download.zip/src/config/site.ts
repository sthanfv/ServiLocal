export type NavItem = {
  title: string;
  href: string;
  disabled?: boolean;
  external?: boolean;
  icon?: React.ComponentType<{ className?: string }>;
};

export type SiteConfig = {
  name: string;
  description: string;
  url: string;
  ogImage: string;
  mainNav: NavItem[];
  footerNav: NavItem[];
};

export const siteConfig: SiteConfig = {
  name: "ServiLocal",
  description: "Conectando clientes con proveedores de servicios locales cualificados.",
  url: "https://servilocal.app", // Placeholder, update with actual URL
  ogImage: "https://servilocal.app/og.jpg", // Placeholder, update with actual OG image URL
  mainNav: [
    {
      title: "Inicio",
      href: "/",
    },
    {
      title: "Servicios",
      href: "/servicios",
    },
    {
      title: "Apóyanos",
      href: "/apoyanos",
    },
    {
      title: "Convertirse en Proveedor",
      href: "/convertirse-en-proveedor",
    },
  ],
  footerNav: [
    {
      title: "Términos y Condiciones",
      href: "/terminos-y-condiciones",
    },
    {
      title: "Política de Privacidad",
      href: "/politica-de-privacidad",
    },
    {
      title: "Consejos de Contratación",
      href: "/consejos-contratacion",
    },
    {
      title: "Guía para Proveedores",
      href: "/guia-proveedores",
    }
  ],
};
