# **App Name**: ServicioLocal

## Core Features:

- User Authentication: User authentication using Firebase Authentication, supporting registration, login, logout, and password reset.
- Static Page Content: Implementation of static pages like Terms and Conditions, Privacy Policy, etc., loaded dynamically from Firestore via a Cloud Function.
- Donation Display: Display of active donation methods on the 'Apoyanos' page, fetched from Firestore via a Cloud Function.
- Service Management: Functionality for providers to create, edit, and delete service listings, managing details and images through Cloud Functions and Cloud Storage.
- Service Listings: Display of service listings for clients with filtering options (keyword, category, location).
- User Reviews with AI flagging: Creation and display of user reviews, with an AI-powered tool for flagging suspicious review content that does not appear helpful, or appears inauthentic. All generated content will comply with the requested language.
- Tooltip Implementation: Tooltips added to key icons in the header to provide context (search, notifications).

## Style Guidelines:

- Primary color: Corporate blue (#0D47A1) for a professional and trustworthy feel.
- Background color: Light gray (#F0F2F5) for a clean and modern look.
- Accent color: Defined green (#2ECC71) for calls to action to highlight key interactions.
- Font: 'PT Sans' (sans-serif) for a humanist and readable text.
- Use of simple, clear icons to enhance user understanding.
- Clean and intuitive responsive design, adapting to different screen sizes.
- Subtle transitions and feedback animations to improve user experience.